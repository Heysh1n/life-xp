@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.codecs;

import javax.annotation.ParametersAreNonnullByDefault;
