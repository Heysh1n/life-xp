@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.gui.input.handlers;

import javax.annotation.ParametersAreNonnullByDefault;
