@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.fabric.constants;

import javax.annotation.ParametersAreNonnullByDefault;
