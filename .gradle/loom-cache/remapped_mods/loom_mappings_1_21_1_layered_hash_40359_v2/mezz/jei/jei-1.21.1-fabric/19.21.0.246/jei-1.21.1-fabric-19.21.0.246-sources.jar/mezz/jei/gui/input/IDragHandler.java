package mezz.jei.gui.input;

import java.util.Optional;
import net.minecraft.client.gui.screens.Screen;

public interface IDragHandler {
	Optional<IDragHandler> handleDragStart(Screen screen, UserInput input);

	boolean handleDragComplete(Screen screen, UserInput input);

	default void handleDragCanceled() {

	}
}
