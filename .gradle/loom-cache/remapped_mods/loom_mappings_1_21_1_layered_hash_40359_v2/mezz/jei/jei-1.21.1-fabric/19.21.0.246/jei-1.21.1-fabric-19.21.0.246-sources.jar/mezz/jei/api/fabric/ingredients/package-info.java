@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.fabric.ingredients;

import javax.annotation.ParametersAreNonnullByDefault;
