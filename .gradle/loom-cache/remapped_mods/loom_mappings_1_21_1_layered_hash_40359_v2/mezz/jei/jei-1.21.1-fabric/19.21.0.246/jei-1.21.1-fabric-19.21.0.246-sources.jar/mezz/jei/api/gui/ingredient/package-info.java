@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.gui.ingredient;

import javax.annotation.ParametersAreNonnullByDefault;
