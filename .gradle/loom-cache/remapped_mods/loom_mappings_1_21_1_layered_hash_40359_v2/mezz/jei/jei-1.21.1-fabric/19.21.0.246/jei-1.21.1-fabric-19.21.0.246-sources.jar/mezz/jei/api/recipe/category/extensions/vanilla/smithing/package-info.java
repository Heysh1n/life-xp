@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.category.extensions.vanilla.smithing;

import javax.annotation.ParametersAreNonnullByDefault;
