package com.hs1n.lifeXp_challenge.item;

import com.hs1n.lifeXp_challenge.util.ExperienceUtils;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_437;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Динамический пузырёк опыта, хранящий точное количество очков опыта в Data Components.
 * При Shift + ПКМ переливает опыт из игрока в пузырёк (с налогом 10%).
 * При обычном ПКМ мгновенно возвращает все очки опыта игроку и возвращает пустую бутылочку.
 */
public class DynamicXpBottleItem extends class_1792 {

    public static final String NBT_STORED_XP = "StoredXp";

    public DynamicXpBottleItem(class_1792.class_1793 properties) {
        super(properties);
    }

    public static int getStoredXp(class_1799 stack) {
        class_9279 customData = stack.method_57824(class_9334.field_49628);
        if (customData == null) return 0;
        class_2487 tag = customData.method_57461();
        return tag.method_10550(NBT_STORED_XP);
    }

    public static void setStoredXp(class_1799 stack, int points) {
        class_9279.method_57452(class_9334.field_49628, stack, tag -> {
            tag.method_10569(NBT_STORED_XP, Math.max(0, points));
        });
    }

    public static void addStoredXp(class_1799 stack, int points) {
        if (points <= 0) return;
        int current = getStoredXp(stack);
        setStoredXp(stack, current + points);
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return 72000;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (player.method_5715()) {
            if (ExperienceUtils.getPlayerTotalXp(player) > 0) {
                player.method_6019(hand);
                return class_1271.method_22428(stack);
            } else {
                return class_1271.method_22431(stack);
            }
        } else {
            // Обычный ПКМ — поглощение опыта
            int stored = getStoredXp(stack);
            if (stored > 0) {
                if (!level.method_8608()) {
                    player.method_7255(stored);
                    level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                            class_3417.field_14839, class_3419.field_15248, 1.0f, 1.0f);
                    level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                            class_3417.field_14709, class_3419.field_15248, 0.6f, 1.2f);

                    stack.method_7934(1);
                    class_1799 emptyBottle = new class_1799(class_1802.field_8469);
                    if (!player.method_31548().method_7394(emptyBottle)) {
                        player.method_7328(emptyBottle, false);
                    }
                }
                return class_1271.method_29237(stack, level.method_8608());
            }
        }

        return class_1271.method_22430(stack);
    }

    @Override
    public void method_7852(class_1937 level, class_1309 livingEntity, class_1799 stack, int remainingUseTicks) {
        if (!(livingEntity instanceof class_1657 player)) return;

        int ticksUsed = method_7881(stack, livingEntity) - remainingUseTicks;
        if (ticksUsed > 0 && ticksUsed % 10 == 0) {
            if (!level.method_8608()) {
                if (ExperienceUtils.getPlayerTotalXp(player) > 0) {
                    // Забираем эквивалент 1 уровня
                    int targetLevel = Math.max(0, player.field_7520 - 1);
                    int needed = ExperienceUtils.getXpNeededToLevelUp(targetLevel);
                    int deducted = ExperienceUtils.deductPlayerXp(player, needed);

                    if (deducted > 0) {
                        int stored = (int) Math.round(deducted * 0.9); // 10% налог в пустоту
                        if (stored <= 0) stored = 1;
                        addStoredXp(stack, stored);

                        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                                class_3417.field_14779, class_3419.field_15248, 0.8f, 1.0f + (float) (Math.random() * 0.2));
                        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                                class_3417.field_14627, class_3419.field_15248, 0.4f, 1.2f);
                    }
                } else {
                    player.method_6021();
                }
            }
        }
    }

    /**
     * Динамический цвет жидкости от светло-зелёного (мало опыта) до глубокого тёмно-зелёного (много опыта).
     */
    public static int getXpColor(class_1799 stack) {
        int xpPoints = getStoredXp(stack);
        float t = Math.clamp((float) xpPoints / 3000.0f, 0.0f, 1.0f);
        // Интерполяция от яркого салатового (160, 255, 60) к насыщенному тёмно-зелёному (10, 80, 20)
        int r = (int) (160 + t * (10 - 160));
        int g = (int) (255 + t * (80 - 255));
        int b = (int) (60 + t * (20 - 60));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return getStoredXp(stack) > 0;
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        int storedXp = getStoredXp(stack);
        int approxLevels = ExperienceUtils.calculateLevelFromXp(storedXp);

        tooltip.add(class_2561.method_43469("lifexp.xp_bottle.stored_points", storedXp, approxLevels)
                .method_27695(class_124.field_1060, class_124.field_1067));

        if (class_437.method_25442()) {
            tooltip.add(class_2561.method_43471("item.life_xp_challenge.dynamic_xp_bottle.desc")
                    .method_27692(class_124.field_1054));
        } else {
            tooltip.add(class_2561.method_43471("lifexp.tooltip.hold_shift")
                    .method_27692(class_124.field_1063));
        }
    }
}
