package com.hs1n.lifeXp_challenge.compat.jei;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.registry.ModPotions;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.recipe.vanilla.IJeiBrewingRecipe;
import mezz.jei.api.recipe.vanilla.IVanillaRecipeFactory;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import java.util.ArrayList;
import java.util.List;

@JeiPlugin
public class LifeXpJeiPlugin implements IModPlugin {

    public static final class_2960 PLUGIN_UID = class_2960.method_60655(LifeXpChallenge.MOD_ID, "jei_plugin");

    @Override
    public class_2960 getPluginUid() {
        return PLUGIN_UID;
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        // ── Информационные вкладки предметов ──
        registration.addIngredientInfo(
                ModItems.LIFE_BOTTLE.get(),
                class_2561.method_43471("jei.life_xp_challenge.life_bottle.info")
        );
        registration.addIngredientInfo(
                ModItems.DYNAMIC_XP_BOTTLE.get(),
                class_2561.method_43471("jei.life_xp_challenge.dynamic_xp_bottle.info")
        );
        registration.addIngredientInfo(
                ModItems.SHIELD_CORE.get(),
                class_2561.method_43471("jei.life_xp_challenge.shield_core.info")
        );

        // ── Рецепты варки зельеварения в JEI ──
        IVanillaRecipeFactory factory = registration.getVanillaRecipeFactory();
        List<IJeiBrewingRecipe> brewingRecipes = new ArrayList<>();

        // 1. Awkward Potion + shield_core = Potion of XP Shield I (3:00)
        class_1799 awkward = class_1844.method_57400(class_1802.field_8574, class_1847.field_8999);
        class_1799 xpShield1 = class_1844.method_57400(class_1802.field_8574, ModPotions.XP_SHIELD);
        brewingRecipes.add(factory.createBrewingRecipe(
                List.of(ModItems.SHIELD_CORE.get().method_7854()),
                awkward,
                xpShield1,
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/xp_shield")
        ));

        // 2. Potion of XP Shield I + Redstone = Long Potion of XP Shield I (8:00)
        class_1799 longXpShield1 = class_1844.method_57400(class_1802.field_8574, ModPotions.LONG_XP_SHIELD);
        brewingRecipes.add(factory.createBrewingRecipe(
                List.of(class_1802.field_8725.method_7854()),
                xpShield1,
                longXpShield1,
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/long_xp_shield")
        ));

        // 3. Potion of XP Shield I + Glowstone Dust = Strong Potion of XP Shield II (1:30)
        class_1799 strongXpShield2 = class_1844.method_57400(class_1802.field_8574, ModPotions.STRONG_XP_SHIELD);
        brewingRecipes.add(factory.createBrewingRecipe(
                List.of(class_1802.field_8601.method_7854()),
                xpShield1,
                strongXpShield2,
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/strong_xp_shield")
        ));

        // 4. Strong Potion of XP Shield II + Nether Star = Ultra Potion of XP Shield III (1:00)
        class_1799 ultraXpShield3 = class_1844.method_57400(class_1802.field_8574, ModPotions.ULTRA_XP_SHIELD);
        brewingRecipes.add(factory.createBrewingRecipe(
                List.of(class_1802.field_8137.method_7854()),
                strongXpShield2,
                ultraXpShield3,
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/ultra_xp_shield")
        ));

        // 5 & 6. Взрывные (Gunpowder) и Оседающие (Dragon's Breath) зелья для всех 4 ступеней
        List<class_6880<class_1842>> allPotions = List.of(
                ModPotions.XP_SHIELD,
                ModPotions.LONG_XP_SHIELD,
                ModPotions.STRONG_XP_SHIELD,
                ModPotions.ULTRA_XP_SHIELD
        );

        int index = 1;
        for (class_6880<class_1842> potion : allPotions) {
            class_1799 normal = class_1844.method_57400(class_1802.field_8574, potion);
            class_1799 splash = class_1844.method_57400(class_1802.field_8436, potion);
            class_1799 lingering = class_1844.method_57400(class_1802.field_8150, potion);

            // Normal + Gunpowder -> Splash
            brewingRecipes.add(factory.createBrewingRecipe(
                    List.of(class_1802.field_8054.method_7854()),
                    normal,
                    splash,
                    class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/splash_" + index)
            ));

            // Splash + Dragon's Breath -> Lingering
            brewingRecipes.add(factory.createBrewingRecipe(
                    List.of(class_1802.field_8613.method_7854()),
                    splash,
                    lingering,
                    class_2960.method_60655(LifeXpChallenge.MOD_ID, "brewing/lingering_" + index)
            ));

            index++;
        }

        registration.addRecipes(RecipeTypes.BREWING, brewingRecipes);
    }
}
