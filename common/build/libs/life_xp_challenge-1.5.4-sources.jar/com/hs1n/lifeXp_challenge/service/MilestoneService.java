package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import net.minecraft.class_167;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8779;

public class MilestoneService {
    private static final class_2960 MILESTONE_10 = class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/milestone_10");
    private static final class_2960 MILESTONE_50 = class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/milestone_50");
    private static final class_2960 MILESTONE_100 = class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/milestone_100");

    public static void checkMilestones(class_3222 player) {
        int maxLevel = LifeXpConfig.INSTANCE.getMaxLevel();
        if (maxLevel <= 0) return;

        float progress = (float) player.field_7520 / (float) maxLevel;

        if (progress >= 0.10f) grantAdvancement(player, MILESTONE_10, "lifexp.milestone.10");
        if (progress >= 0.50f) grantAdvancement(player, MILESTONE_50, "lifexp.milestone.50");
        if (progress >= 1.00f) grantAdvancement(player, MILESTONE_100, "lifexp.milestone.100");
    }

    private static void grantAdvancement(class_3222 player, class_2960 advancementId, String translationKey) {
        class_8779 advancement = player.field_13995.method_3851().method_12896(advancementId);
        if (advancement != null) {
            class_167 progress = player.method_14236().method_12882(advancement);
            if (!progress.method_740()) {
                for (String criterion : progress.method_731()) {
                    player.method_14236().method_12878(advancement, criterion);
                }
                player.method_43496(class_2561.method_43471(translationKey));
            }
        }
    }
}
