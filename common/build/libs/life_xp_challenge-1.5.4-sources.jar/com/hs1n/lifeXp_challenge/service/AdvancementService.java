package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.registry.ModMobEffects;
import net.minecraft.class_1293;
import net.minecraft.class_167;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8779;

public class AdvancementService {

    public static final class_2960 LIFE_OR_DEATH =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/life_or_death");
    public static final class_2960 MINER_VEIN =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/miner_vein");
    public static final class_2960 MASTER_ANGLER =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "main/master_angler");

    private static final String TAG_PREFIX_ORE_XP = "lifexp_ore_xp_";
    private static final String TAG_PREFIX_FISH_XP = "lifexp_fish_xp_";

    public static void checkLifeOrDeath(class_3222 player) {
        if (!player.method_5805() || player.method_6032() > 1.0f) {
            return;
        }
        class_1293 effect = player.method_6112(ModMobEffects.XP_SHIELD);
        if (effect != null && effect.method_5578() >= 2) {
            grantAdvancement(player, LIFE_OR_DEATH);
        }
    }

    public static void addOreXp(class_3222 player, int amount) {
        if (amount <= 0 || isAdvancementDone(player, MINER_VEIN)) return;
        int current = getPlayerTagCount(player, TAG_PREFIX_ORE_XP) + amount;
        setPlayerTagCount(player, TAG_PREFIX_ORE_XP, current);
        if (current >= 1000) {
            grantAdvancement(player, MINER_VEIN);
        }
    }

    public static void addFishingXp(class_3222 player, int amount) {
        if (amount <= 0 || isAdvancementDone(player, MASTER_ANGLER)) return;
        int current = getPlayerTagCount(player, TAG_PREFIX_FISH_XP) + amount;
        setPlayerTagCount(player, TAG_PREFIX_FISH_XP, current);
        if (current >= 500) {
            grantAdvancement(player, MASTER_ANGLER);
        }
    }

    public static boolean isAdvancementDone(class_3222 player, class_2960 id) {
        class_8779 advancement = player.field_13995.method_3851().method_12896(id);
        if (advancement == null) return false;
        return player.method_14236().method_12882(advancement).method_740();
    }

    public static void grantAdvancement(class_3222 player, class_2960 advancementId) {
        class_8779 advancement = player.field_13995.method_3851().method_12896(advancementId);
        if (advancement != null) {
            class_167 progress = player.method_14236().method_12882(advancement);
            if (!progress.method_740()) {
                for (String criterion : progress.method_731()) {
                    player.method_14236().method_12878(advancement, criterion);
                }
            }
        }
    }

    private static int getPlayerTagCount(class_3222 player, String prefix) {
        for (String tag : player.method_5752()) {
            if (tag.startsWith(prefix)) {
                try {
                    return Integer.parseInt(tag.substring(prefix.length()));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return 0;
    }

    private static void setPlayerTagCount(class_3222 player, String prefix, int count) {
        player.method_5752().removeIf(tag -> tag.startsWith(prefix));
        player.method_5780(prefix + count);
    }
}
