package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.item.LifeBottleItem;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.util.MessageUtils;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3222;
import net.minecraft.class_8111;

/**
 * Сервис управления сохранением и восстановлением инвентаря через Пузырёк Жизни (Data Components 1.21.1).
 */
public final class LifeBottleService {

    private static final Map<UUID, class_1799> VOID_SAVED_BOTTLES = new ConcurrentHashMap<>();

    private LifeBottleService() {}

    public static void storeVoidBottle(UUID playerUuid, class_1799 bottle) {
        VOID_SAVED_BOTTLES.put(playerUuid, bottle);
    }

    public static class_1799 retrieveVoidBottle(UUID playerUuid) {
        return VOID_SAVED_BOTTLES.remove(playerUuid);
    }

    /**
     * Обрабатывает гибель игрока при наличии пустого Пузырька Жизни.
     * @return true, если инвентарь был упакован в бутылёк и стандартный дроп отменяется.
     */
    public static boolean handleDeathInventory(class_3222 player) {
        if (player.method_37908().method_8450().method_8355(class_1928.field_19389)) {
            return false;
        }

        class_1661 inventory = player.method_31548();

        // 1. Поиск пустого бутылька жизни
        int bottleSlot = -1;
        boolean isArmor = false;
        boolean isOffhand = false;
        class_1799 bottleStack = class_1799.field_8037;

        // Основной инвентарь (0..35)
        for (int i = 0; i < inventory.field_7547.size(); i++) {
            class_1799 stack = inventory.field_7547.get(i);
            if (stack.method_31574(ModItems.LIFE_BOTTLE.get()) && !LifeBottleItem.hasSavedInventory(stack)) {
                bottleSlot = i;
                bottleStack = stack;
                break;
            }
        }

        // Вторая рука (150)
        if (bottleStack.method_7960()) {
            for (int i = 0; i < inventory.field_7544.size(); i++) {
                class_1799 stack = inventory.field_7544.get(i);
                if (stack.method_31574(ModItems.LIFE_BOTTLE.get()) && !LifeBottleItem.hasSavedInventory(stack)) {
                    bottleSlot = i;
                    bottleStack = stack;
                    isOffhand = true;
                    break;
                }
            }
        }

        // Слоты брони (100..103)
        if (bottleStack.method_7960()) {
            for (int i = 0; i < inventory.field_7548.size(); i++) {
                class_1799 stack = inventory.field_7548.get(i);
                if (stack.method_31574(ModItems.LIFE_BOTTLE.get()) && !LifeBottleItem.hasSavedInventory(stack)) {
                    bottleSlot = i;
                    bottleStack = stack;
                    isArmor = true;
                    break;
                }
            }
        }

        if (bottleStack.method_7960()) {
            return false;
        }

        // 2. Создаем заполненный экземпляр бутылька
        class_1799 filledBottle = bottleStack.method_7972();
        filledBottle.method_7939(1);
        // Тратим 1 единицу прочности
        filledBottle.method_7974(filledBottle.method_7919() + 1);

        // 3. Сериализуем все 41 слот инвентаря через Data Components
        class_2499 listTag = new class_2499();

        // Основные слоты (0..35)
        for (int i = 0; i < inventory.field_7547.size(); i++) {
            class_1799 stack = inventory.field_7547.get(i);
            if (stack.method_7960()) continue;
            if (!isArmor && !isOffhand && i == bottleSlot) {
                if (stack.method_7947() > 1) {
                    class_1799 remaining = stack.method_7972();
                    remaining.method_7934(1);
                    class_2487 tag = (class_2487) remaining.method_57358(player.method_56673());
                    tag.method_10569("Slot", i);
                    listTag.add(tag);
                }
            } else {
                class_2487 tag = (class_2487) stack.method_57358(player.method_56673());
                tag.method_10569("Slot", i);
                listTag.add(tag);
            }
        }

        // Слоты брони (100..103)
        for (int i = 0; i < inventory.field_7548.size(); i++) {
            class_1799 stack = inventory.field_7548.get(i);
            if (stack.method_7960()) continue;
            if (isArmor && i == bottleSlot) {
                if (stack.method_7947() > 1) {
                    class_1799 remaining = stack.method_7972();
                    remaining.method_7934(1);
                    class_2487 tag = (class_2487) remaining.method_57358(player.method_56673());
                    tag.method_10569("Slot", 100 + i);
                    listTag.add(tag);
                }
            } else {
                class_2487 tag = (class_2487) stack.method_57358(player.method_56673());
                tag.method_10569("Slot", 100 + i);
                listTag.add(tag);
            }
        }

        // Вторая рука (150)
        for (int i = 0; i < inventory.field_7544.size(); i++) {
            class_1799 stack = inventory.field_7544.get(i);
            if (stack.method_7960()) continue;
            if (isOffhand && i == bottleSlot) {
                if (stack.method_7947() > 1) {
                    class_1799 remaining = stack.method_7972();
                    remaining.method_7934(1);
                    class_2487 tag = (class_2487) remaining.method_57358(player.method_56673());
                    tag.method_10569("Slot", 150 + i);
                    listTag.add(tag);
                }
            } else {
                class_2487 tag = (class_2487) stack.method_57358(player.method_56673());
                tag.method_10569("Slot", 150 + i);
                listTag.add(tag);
            }
        }

        // Сохраняем в Data Components (1.21.1)
        LifeBottleItem.setSavedInventory(filledBottle, listTag);

        // 4. Очищаем инвентарь игрока
        inventory.method_5448();

        // 5. Проверка защиты от падения в пустоту (Void Protection)
        class_1282 damageSource = player.method_6081();
        boolean isVoid = (damageSource != null && damageSource.method_49708(class_8111.field_42347))
                || player.method_23318() < player.method_37908().method_31607();

        if (isVoid) {
            storeVoidBottle(player.method_5667(), filledBottle);
            MessageUtils.sendInfo(player, "lifexp.message.bottle_void_saved");
        } else {
            double spawnY = Math.max(player.method_23318(), player.method_37908().method_31607() + 1.0);
            class_1542 entity = new class_1542(player.method_37908(), player.method_23317(), spawnY, player.method_23321(), filledBottle);
            entity.method_5684(true);
            entity.method_35190();
            entity.method_6982(10);
            player.method_37908().method_8649(entity);
            MessageUtils.sendInfo(player, "lifexp.message.bottle_saved");
        }

        return true;
    }
}
