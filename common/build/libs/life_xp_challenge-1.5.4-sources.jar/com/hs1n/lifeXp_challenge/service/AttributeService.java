package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.config.AttributeConfigNode;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

/**
 * Сервис пересчёта атрибутов игрока на основе его уровня опыта.
 * Работает строго в O(1).
 * Кэширует уровень опыта игрока и срабатывает ТОЛЬКО при изменении experienceLevel.
 * Игнорирует изменения experienceProgress, защищая сервер от Watchdog Crash.
 */
public final class AttributeService {

    private static final String MOD_ID = "life_xp_challenge";

    /** Маппинг конфиг-ключ → ванильный Holder<Attribute> (строго 1.21.1). */
    private static final Map<String, class_6880<class_1320>> ATTRIBUTE_MAP = new LinkedHashMap<>();

    /** Кэш уровня игрока (UUID -> experienceLevel) для O(1) проверки. */
    private static final Map<UUID, Integer> LAST_LEVEL_CACHE = new ConcurrentHashMap<>();

    static {
        ATTRIBUTE_MAP.put("max_health",               class_5134.field_23716);
        ATTRIBUTE_MAP.put("movement_speed",           class_5134.field_23719);
        ATTRIBUTE_MAP.put("attack_damage",            class_5134.field_23721);
        ATTRIBUTE_MAP.put("attack_speed",             class_5134.field_23723);
        ATTRIBUTE_MAP.put("armor_toughness",          class_5134.field_23725);
        ATTRIBUTE_MAP.put("knockback_resistance",     class_5134.field_23718);
        ATTRIBUTE_MAP.put("block_interaction_range",  class_5134.field_47758);
        ATTRIBUTE_MAP.put("entity_interaction_range", class_5134.field_47759);
        ATTRIBUTE_MAP.put("block_break_speed",        class_5134.field_49076);
        ATTRIBUTE_MAP.put("sneaking_speed",           class_5134.field_51584);
        ATTRIBUTE_MAP.put("submerged_mining_speed",   class_5134.field_51576);
        ATTRIBUTE_MAP.put("sweeping_damage_ratio",    class_5134.field_51577);
        ATTRIBUTE_MAP.put("safe_fall_distance",       class_5134.field_49079);
        ATTRIBUTE_MAP.put("oxygen_bonus",             class_5134.field_51583);
        ATTRIBUTE_MAP.put("burning_time",             class_5134.field_51579);
    }

    private AttributeService() {}

    /** Очистить кэш для конкретного игрока (при дисконнекте/респавне). */
    public static void clearCache(UUID uuid) {
        if (uuid != null) {
            LAST_LEVEL_CACHE.remove(uuid);
        }
    }

    /** Очистить кэш для всех игроков (при смене конфига/пресета). */
    public static void clearAllCache() {
        LAST_LEVEL_CACHE.clear();
    }

    // ── Интерполяция (O(1)) ───────────────────────────────────────

    /**
     * Кусочно-линейная интерполяция с динамическим maxLevel (O(1)).
     */
    public static double interpolate(com.hs1n.lifeXp_challenge.config.AttributeConfigNode node, int level, int maxLevel) {
        if (node.getFormulaMode() == com.hs1n.lifeXp_challenge.config.FormulaMode.FORMULA) {
            if (level <= 0) return node.getFormulaBase();
            double base = node.getFormulaBase();
            double multiplier = node.getFormulaMultiplier();
            double exponent = node.getFormulaExponent();
            return base + Math.pow(level * multiplier, exponent);
        }

        if (maxLevel <= 0) maxLevel = 1;
        if (level <= 0) return node.getStartValue();
        if (level >= maxLevel) return node.getEndValue();

        int half = maxLevel / 2;
        if (half <= 0) half = 1;

        if (level <= half) {
            double t = (double) level / half;
            return node.getStartValue() + (node.getMidValue() - node.getStartValue()) * t;
        } else {
            double t = (double) (level - half) / (maxLevel - half);
            return node.getMidValue() + (node.getEndValue() - node.getMidValue()) * t;
        }
    }

    /**
     * Кусочно-линейная интерполяция для произвольных значений (O(1)).
     */
    public static double interpolate(double startVal, double midVal, double endVal, int level, int maxLevel) {
        if (maxLevel <= 0) maxLevel = 1;
        if (level <= 0) return startVal;
        if (level >= maxLevel) return endVal;

        int half = maxLevel / 2;
        if (half <= 0) half = 1;

        if (level <= half) {
            double t = (double) level / half;
            return startVal + (midVal - startVal) * t;
        } else {
            double t = (double) (level - half) / (maxLevel - half);
            return midVal + (endVal - midVal) * t;
        }
    }

    /** ResourceLocation для модификатора конкретного атрибута. */
    private static class_2960 modifierId(String attrKey) {
        return class_2960.method_60655(MOD_ID, "xp_scaling_" + attrKey);
    }

    // ── Применение (O(1)) ─────────────────────────────────────────

    /**
     * Стандартный пересчёт атрибутов с проверкой кэша.
     * Срабатывает ТОЛЬКО если player.experienceLevel действительно изменился.
     */
    public static void recalculate(class_1657 player) {
        recalculate(player, false);
    }

    /**
     * Пересчитать и применить все модификаторы для игрока.
     * @param force если true, пересчитывает даже если уровень совпадает с кэшем (например, смена конфига или респавн).
     */
    public static void recalculate(class_1657 player, boolean force) {
        if (player == null) return;
        int level = player.field_7520;
        UUID uuid = player.method_5667();

        if (!force) {
            Integer cachedLevel = LAST_LEVEL_CACHE.get(uuid);
            if (cachedLevel != null && cachedLevel == level) {
                // Уровень не изменился — выходим в O(1), игнорируя опыт-прогресс и не спамя пересчёт
                return;
            }
        }
        LAST_LEVEL_CACHE.put(uuid, level);

        LifeXpConfig config = LifeXpConfig.INSTANCE;
        int maxLevel = config.getMaxLevel();

        for (Map.Entry<String, class_6880<class_1320>> entry : ATTRIBUTE_MAP.entrySet()) {
            String key                   = entry.getKey();
            class_6880<class_1320> holder      = entry.getValue();
            AttributeConfigNode node     = config.getNode(key);
            if (node == null) continue;

            class_1324 instance = player.method_5996(holder);
            if (instance == null) continue;

            double value        = interpolate(node, level, maxLevel);
            class_2960 id = modifierId(key);

            // Удаляем старый, ставим новый (zero-tick обновление)
            instance.method_6200(id);
            if (value != 0.0) {
                instance.method_26837(new class_1322(
                        id, value, class_1322.class_1323.field_6328
                ));
            }
        }

        // Принудительно срезаем текущее здоровье до нового максимума (zero-tick fix)
        double newMaxHealth = player.method_45325(class_5134.field_23716);
        if (player.method_6032() > newMaxHealth) {
            player.method_6033((float) newMaxHealth);
        }

        if (player instanceof net.minecraft.class_3222 serverPlayer) {
            MilestoneService.checkMilestones(serverPlayer);
        }
    }
}
