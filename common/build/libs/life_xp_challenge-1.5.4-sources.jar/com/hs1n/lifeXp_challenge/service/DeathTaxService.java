package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import net.minecraft.class_8103;

public class DeathTaxService {
    private static final Map<UUID, class_1282> LAST_FATAL_SOURCES = new ConcurrentHashMap<>();

    public static void onPlayerDeath(class_3222 player, class_1282 source) {
        LAST_FATAL_SOURCES.put(player.method_5667(), source);
    }

    public static double calculateSmartTax(class_3222 player) {
        class_1282 source = LAST_FATAL_SOURCES.get(player.method_5667());
        double baseTax = LifeXpConfig.INSTANCE.getDeathXpTax();
        
        if (source == null) return baseTax;

        // Эпичные битвы (Визер, Варден, Дракон Края, боссы)
        if (source.method_5529() != null) {
            String entityName = source.method_5529().method_5864().method_5882(); // например, entity.minecraft.wither
            if (entityName.contains("wither") || entityName.contains("warden") || entityName.contains("ender_dragon")) {
                return Math.max(0.01, baseTax * 0.1); // 10% от текущего налога
            }
        }

        // Глупые смерти (Лава, Падение, Утопление, Огонь, Голодание)
        if (source.method_48789(class_8103.field_42250) || 
            source.method_48789(class_8103.field_42246) || 
            source.method_48789(class_8103.field_42251) ||
            source.method_5525().equals("lava") ||
            source.method_5525().equals("starve") ||
            source.method_5525().equals("inWall")) {
            return Math.min(1.0, baseTax * 5.0); // Жестокий налог, например 50% если база 10%
        }

        return baseTax;
    }
}
