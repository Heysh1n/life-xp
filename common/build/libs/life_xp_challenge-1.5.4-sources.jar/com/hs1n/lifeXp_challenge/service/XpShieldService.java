package com.hs1n.lifeXp_challenge.service;

import com.hs1n.lifeXp_challenge.registry.ModMobEffects;
import com.hs1n.lifeXp_challenge.util.ExperienceUtils;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8103;

public class XpShieldService {

    public static float absorbDamage(class_3222 player, class_1282 source, float amount) {
        if (amount <= 0.0f || source.method_48789(class_8103.field_42242)) {
            return amount;
        }

        // Поглощение урона срабатывает ТОЛЬКО если на игроке висит эффект xp_shield
        class_1293 effect = player.method_6112(ModMobEffects.XP_SHIELD);
        if (effect == null) {
            return amount;
        }

        long totalXp = ExperienceUtils.getPlayerTotalXp(player);
        if (totalXp <= 0L) {
            return amount;
        }

        // Математика скейлинга поглощения:
        // Уровень I   (amplifier 0):  25%
        // Уровень II  (amplifier 1):  50%
        // Уровень III+ (amplifier 2+): 75%
        int amplifier = effect.method_5578();
        float absorbPercent;
        if (amplifier <= 0) {
            absorbPercent = 0.25f;
        } else if (amplifier == 1) {
            absorbPercent = 0.50f;
        } else {
            absorbPercent = 0.75f;
        }

        float targetAbsorb = amount * absorbPercent;

        // Опыт сжигается эквивалентно поглощенному урону.
        // Если опыта не хватает, сгорает всё до 0, а остаток урона бьет по здоровью.
        float maxAbsorbable = (float) totalXp;
        float damageToAbsorb = Math.max(0.0f, Math.min(targetAbsorb, maxAbsorbable));

        long xpToDeduct = (long) Math.ceil((double) damageToAbsorb);
        xpToDeduct = Math.max(0L, Math.min(totalXp, xpToDeduct));

        if (damageToAbsorb > 0.0f && xpToDeduct > 0L) {
            long newXp = Math.max(0L, totalXp - xpToDeduct);
            newXp = Math.min(totalXp, newXp);

            ExperienceUtils.setPlayerTotalXp(player, newXp);

            player.method_37908().method_8396(null, player.method_24515(), class_3417.field_26982, class_3419.field_15248, 0.7f, 1.2f);

            return Math.max(0.0f, amount - damageToAbsorb);
        }

        return amount;
    }
}
