package com.hs1n.lifeXp_challenge.client;

import com.hs1n.lifeXp_challenge.client.hud.LifeXpHudOverlay;
import com.hs1n.lifeXp_challenge.item.LifeBottleItem;
import com.hs1n.lifeXp_challenge.network.LifeXpNetworking;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import dev.architectury.event.events.client.ClientGuiEvent;
import dev.architectury.registry.client.rendering.ColorHandlerRegistry;

public class LifeXpChallengeClient {

    public static void init() {
        // Регистрируем получатель пакетов Kill Streak
        LifeXpNetworking.registerClientReceiver();

        // Регистрируем HUD-оверлей
        ClientGuiEvent.RENDER_HUD.register(LifeXpHudOverlay::render);
        LifeXpVisualsClient.register();
        ColorHandlerRegistry.registerItemColors((stack, tintIndex) -> {
            if (tintIndex != 0) return -1;
            
            int stored = stack.method_57825(net.minecraft.class_9334.field_49628, net.minecraft.class_9279.field_49302).method_57461().method_10550("StoredXp");
            if (stored <= 0) return 0xFFA0FF3C; // 160, 255, 60 (default color, fully opaque)
            
            float ratio = Math.clamp((float) stored / 3000f, 0f, 1f);
            int r = (int) (160 - 150 * ratio); // 160 -> 10
            int g = (int) (255 - 175 * ratio); // 255 -> 80
            int b = (int) (60 - 40 * ratio);   // 60 -> 20
            
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }, ModItems.DYNAMIC_XP_BOTTLE.get());

        ColorHandlerRegistry.registerItemColors((stack, tintIndex) -> {
            if (tintIndex != 0) return -1;
            return LifeBottleItem.hasSavedInventory(stack) ? 0xFFF59E0B : 0xFFDC2626;
        }, ModItems.LIFE_BOTTLE.get());
    }
}
