package com.hs1n.lifeXp_challenge.client;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.event.events.client.ClientGuiEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

/**
 * Клиентские визуальные эффекты, заменяющие легаси-туман (FogRenderer mixin).
 * <p>
 * 1. Динамическая виньетка (HUD overlay) — края экрана затемняются при низком XP.
 * 2. Частицы пепла (ASH) — спавнятся вокруг игрока при очень низком уровне опыта.
 */
public final class LifeXpVisualsClient {

    private static final class_2960 VIGNETTE =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "textures/gui/vignette.png");

    private LifeXpVisualsClient() {}

    /** Вызывается из {@link LifeXpChallengeClient#init()} один раз. */
    public static void register() {
        // HUD-оверлей виньетки
        ClientGuiEvent.RENDER_HUD.register(LifeXpVisualsClient::renderVignette);
        // Тик для спавна частиц
        ClientTickEvent.CLIENT_POST.register(LifeXpVisualsClient::onClientTick);
    }

    // ═══════════════════════════════════════════════════════════
    //  Виньетка
    // ═══════════════════════════════════════════════════════════

    private static void renderVignette(class_332 guiGraphics, class_9779 delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player.method_29504() || player.method_7325() || player.method_7337()) return;

        LifeXpConfig config = LifeXpConfig.INSTANCE;
        int maxLevel = Math.max(1, config.getMaxLevel());
        float currentXp = player.field_7520;

        // alpha = 1.0 при 0 XP, 0.0 при ≥ 50% maxLevel
        float alpha = Math.clamp(1.0F - (currentXp / (maxLevel * 0.5F)), 0.0F, 1.0F);
        if (alpha <= 0.001F) return; // Полностью прозрачна — пропускаем рендер

        int screenWidth  = guiGraphics.method_51421();
        int screenHeight = guiGraphics.method_51443();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.method_51422(1.0F, 1.0F, 1.0F, alpha);
        guiGraphics.method_25290(VIGNETTE, 0, 0, 0, 0, screenWidth, screenHeight, screenWidth, screenHeight);
        guiGraphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F); // Сброс цвета
        RenderSystem.disableBlend();
    }

    // ═══════════════════════════════════════════════════════════
    //  Частицы пепла
    // ═══════════════════════════════════════════════════════════

    private static void onClientTick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_746 player = mc.field_1724;
        if (!player.method_7340() || player.method_29504() || player.method_7325() || player.method_7337()) return;

        LifeXpConfig config = LifeXpConfig.INSTANCE;
        int maxLevel = Math.max(1, config.getMaxLevel());
        float threshold = maxLevel * 0.1F; // 10% от капа

        if (player.field_7520 >= threshold) return;

        // 30% шанс каждый тик
        if (player.method_59922().method_43057() > 0.30F) return;

        int count = 1 + player.method_59922().method_43048(2); // 1-2 частицы
        for (int i = 0; i < count; i++) {
            double offsetX = (player.method_59922().method_43058() - 0.5) * 3.0; // радиус ~1.5 блоков
            double offsetY = player.method_59922().method_43058() * 2.0;
            double offsetZ = (player.method_59922().method_43058() - 0.5) * 3.0;

            mc.field_1687.method_8406(
                    class_2398.field_22247,
                    player.method_23317() + offsetX,
                    player.method_23318() + offsetY,
                    player.method_23321() + offsetZ,
                    0.0, 0.0, 0.0
            );
        }
    }
}
