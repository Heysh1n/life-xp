package com.hs1n.lifeXp_challenge.client;

import com.hs1n.lifeXp_challenge.client.gui.PresetSelectionScreen;
import net.minecraft.class_310;

public final class ClientNetworkingHelper {
    private ClientNetworkingHelper() {}

    public static void openPresetScreen() {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new PresetSelectionScreen());
    }
}
