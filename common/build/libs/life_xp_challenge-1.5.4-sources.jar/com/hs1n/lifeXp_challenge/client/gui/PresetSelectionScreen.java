package com.hs1n.lifeXp_challenge.client.gui;

import com.hs1n.lifeXp_challenge.network.LifeXpNetworking;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PresetSelectionScreen extends class_437 {

    public record PresetCard(
            String id,
            class_2561 title,
            class_2561 badge,
            class_2561 description,
            class_2561 stats,
            int accentColor
    ) {}

    private final List<PresetCard> presets = new ArrayList<>();
    private int currentIndex = 0;

    private class_4185 prevButton;
    private class_4185 nextButton;
    private class_4185 selectButton;

    public PresetSelectionScreen() {
        super(class_2561.method_43471("lifexp.gui.preset.title"));
        initPresetList();
    }

    private void initPresetList() {
        presets.add(new PresetCard(
                "core",
                class_2561.method_43471("lifexp.config.preset.core"),
                class_2561.method_43471("lifexp.gui.preset.badge.hardcore"),
                class_2561.method_43471("lifexp.config.preset.core.desc"),
                class_2561.method_43471("lifexp.gui.preset.core.stats"),
                0xFFD700
        ));
        presets.add(new PresetCard(
                "vanilla_plus",
                class_2561.method_43471("lifexp.config.preset.vanilla_plus"),
                class_2561.method_43471("lifexp.gui.preset.badge.balanced"),
                class_2561.method_43471("lifexp.config.preset.vanilla_plus.desc"),
                class_2561.method_43471("lifexp.gui.preset.vanilla_plus.stats"),
                0x55FF55
        ));
        presets.add(new PresetCard(
                "real_hardcore",
                class_2561.method_43471("lifexp.config.preset.real_hardcore"),
                class_2561.method_43471("lifexp.gui.preset.badge.extreme"),
                class_2561.method_43471("lifexp.config.preset.real_hardcore.desc"),
                class_2561.method_43471("lifexp.gui.preset.real_hardcore.stats"),
                0xFF5555
        ));
        presets.add(new PresetCard(
                "core_no_streaks",
                class_2561.method_43471("lifexp.config.preset.core_no_streaks"),
                class_2561.method_43471("lifexp.gui.preset.badge.classic_hardcore"),
                class_2561.method_43471("lifexp.config.preset.core_no_streaks.desc"),
                class_2561.method_43471("lifexp.gui.preset.core_no_streaks.stats"),
                0xFFAA00
        ));
        presets.add(new PresetCard(
                "purist",
                class_2561.method_43471("lifexp.config.preset.purist"),
                class_2561.method_43471("lifexp.gui.preset.badge.purist"),
                class_2561.method_43471("lifexp.config.preset.purist.desc"),
                class_2561.method_43471("lifexp.gui.preset.purist.stats"),
                0x55FFFF
        ));
        presets.add(new PresetCard(
                "baby_mode",
                class_2561.method_43471("lifexp.config.preset.baby_mode"),
                class_2561.method_43471("lifexp.gui.preset.badge.casual"),
                class_2561.method_43471("lifexp.config.preset.baby_mode.desc"),
                class_2561.method_43471("lifexp.gui.preset.baby_mode.stats"),
                0xFF55FF
        ));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int cardWidth = 320;
        int cardHeight = 200;
        int cardX = (this.field_22789 - cardWidth) / 2;
        int cardY = (this.field_22790 - cardHeight) / 2 + 10;

        int buttonY = cardY + cardHeight - 32;

        this.prevButton = this.method_37063(
                class_4185.method_46430(class_2561.method_43470("◀"), btn -> {
                    if (currentIndex > 0) {
                        currentIndex--;
                    } else {
                        currentIndex = presets.size() - 1;
                    }
                }).method_46434(cardX + 16, buttonY, 36, 20).method_46431()
        );

        this.selectButton = this.method_37063(
                class_4185.method_46430(class_2561.method_43471("lifexp.gui.preset.select").method_27692(class_124.field_1067), btn -> {
                    PresetCard current = presets.get(currentIndex);
                    LifeXpNetworking.sendChoosePreset(current.id());
                    this.method_25419();
                }).method_46434(cardX + 60, buttonY, cardWidth - 120, 20).method_46431()
        );

        this.nextButton = this.method_37063(
                class_4185.method_46430(class_2561.method_43470("▶"), btn -> {
                    if (currentIndex < presets.size() - 1) {
                        currentIndex++;
                    } else {
                        currentIndex = 0;
                    }
                }).method_46434(cardX + cardWidth - 52, buttonY, 36, 20).method_46431()
        );
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Simple dark vignette/gradient without vanilla blur shaders
        guiGraphics.method_25296(0, 0, this.field_22789, this.field_22790, 0x90000000, 0xC0000000);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        int cardWidth = 320;
        int cardHeight = 200;
        int cardX = (this.field_22789 - cardWidth) / 2;
        int cardY = (this.field_22790 - cardHeight) / 2 + 10;

        // Card body
        guiGraphics.method_25294(cardX, cardY, cardX + cardWidth, cardY + cardHeight, 0xE0121216);
        guiGraphics.method_49601(cardX, cardY, cardWidth, cardHeight, 0xFF4A4D59);

        // Titles
        guiGraphics.method_27534(this.field_22793, class_2561.method_43471("lifexp.gui.preset.title").method_27695(class_124.field_1065, class_124.field_1067), this.field_22789 / 2, cardY - 24, 0xFFFFFF);
        guiGraphics.method_27534(this.field_22793, class_2561.method_43471("lifexp.gui.preset.subtitle").method_27692(class_124.field_1080), this.field_22789 / 2, cardY - 12, 0xAAAAAA);

        if (!presets.isEmpty()) {
            PresetCard current = presets.get(currentIndex);

            // Card Header: Preset Title
            guiGraphics.method_27534(this.field_22793, current.title(), this.field_22789 / 2, cardY + 12, current.accentColor());

            // Badge
            guiGraphics.method_27534(this.field_22793, current.badge(), this.field_22789 / 2, cardY + 26, 0xAAAAAA);

            // Separator line
            guiGraphics.method_25292(cardX + 16, cardX + cardWidth - 16, cardY + 38, 0xFF3A3D48);

            // Description
            guiGraphics.method_51440(this.field_22793, current.description(), cardX + 20, cardY + 46, cardWidth - 40, 0xCCCCCC);

            // Modifiers / Stats section
            guiGraphics.method_27535(this.field_22793, class_2561.method_43471("lifexp.gui.preset.modifiers_header").method_27695(class_124.field_1054, class_124.field_1073), cardX + 20, cardY + 86, 0xFFFF55);
            guiGraphics.method_51440(this.field_22793, current.stats(), cardX + 20, cardY + 100, cardWidth - 40, 0xEEEEEE);

            // Page indicator (e.g. 1 / 6)
            String pageStr = (currentIndex + 1) + " / " + presets.size();
            guiGraphics.method_27534(this.field_22793, class_2561.method_43470(pageStr).method_27692(class_124.field_1063), this.field_22789 / 2, cardY + cardHeight - 44, 0x888888);
        }
    }
}
