package com.hs1n.lifeXp_challenge.event;

import com.hs1n.lifeXp_challenge.loot.AnomalyFishingLootFunction;
import com.hs1n.lifeXp_challenge.loot.HasAnomalyAnglerCondition;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import dev.architectury.event.events.common.LootEvent;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_77;

public final class FishingLootHandler {

    public static void init() {
        LootEvent.MODIFY_LOOT_TABLE.register((key, context, builtin) -> {
            if (class_39.field_854.equals(key)) {
                class_55.class_56 pool = class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_356(HasAnomalyAnglerCondition.builder())
                        .method_351(class_77.method_411(ModItems.SHIELD_CORE.get()).method_437(10))
                        .method_351(class_77.method_411(ModItems.LIFE_BOTTLE.get()).method_437(5))
                        .method_351(class_77.method_411(ModItems.DYNAMIC_XP_BOTTLE.get()).method_437(10))
                        .method_353(AnomalyFishingLootFunction.builder());

                context.addPool(pool);
            }
        });
    }

    private FishingLootHandler() {}
}
