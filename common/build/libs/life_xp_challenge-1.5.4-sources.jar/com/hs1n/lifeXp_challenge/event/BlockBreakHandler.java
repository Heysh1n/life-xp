package com.hs1n.lifeXp_challenge.event;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.util.ExperienceOrbHelper;
import com.hs1n.lifeXp_challenge.util.ExperienceUtils;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.BlockEvent;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class BlockBreakHandler {
    public static final class_2960 XP_HARVESTER_ID = class_2960.method_60655(LifeXpChallenge.MOD_ID, "xp_harvester");
    public static final class_5321<class_1887> XP_HARVESTER_KEY = class_5321.method_29179(class_7924.field_41265, XP_HARVESTER_ID);

    public static void init() {
        BlockEvent.BREAK.register((level, pos, state, player, xp) -> {
            if (!(level instanceof class_3218 serverLevel) || !(player instanceof class_3222 serverPlayer)) {
                return EventResult.pass();
            }

            if (serverPlayer.method_7337()) {
                return EventResult.pass();
            }

            class_1799 mainHand = serverPlayer.method_6047();
            int harvesterLevel = getHarvesterLevel(mainHand);
            if (harvesterLevel <= 0) {
                return EventResult.pass();
            }

            // 1. Созревший CropBlock (isMaxAge) -> спавн 1-2 ExperienceOrb
            if (state.method_26204() instanceof class_2302 cropBlock && cropBlock.method_9825(state)) {
                int orbCount = 1 + serverPlayer.method_59922().method_43048(2);
                for (int i = 0; i < orbCount; i++) {
                    serverLevel.method_8649(new class_1303(
                            serverLevel,
                            pos.method_10263() + 0.5,
                            pos.method_10264() + 0.5,
                            pos.method_10260() + 0.5,
                            1
                    ));
                }
            }
            // 2. Ancient Debris -> 1% от текущего пула опыта игрока (макс 500 XP)
            else if (state.method_27852(class_2246.field_22109)) {
                long totalXp = ExperienceUtils.getPlayerTotalXp(serverPlayer);
                int bonus = (int) Math.min(500, Math.max(1, (long) (totalXp * 0.01)));
                if (bonus > 0) {
                    ExperienceOrbHelper.spawnClumpedOrb(serverLevel, class_243.method_24953(pos), bonus);
                }
            }
            // 3. Ванильная руда (железо, медь, золото, лазурит, редстоун, алмазы) -> бонусный опыт от уровня чар
            else if (isVanillaOre(state)) {
                int bonus = harvesterLevel * (1 + serverPlayer.method_59922().method_43048(2));
                ExperienceOrbHelper.spawnClumpedOrb(serverLevel, class_243.method_24953(pos), bonus);
            }

            return EventResult.pass();
        });
    }

    public static int getHarvesterLevel(class_1799 stack) {
        if (stack.method_7960()) return 0;
        class_9304 enchantments = stack.method_57825(class_9334.field_49633, class_9304.field_49385);
        for (var entry : enchantments.method_57539()) {
            if (entry.getKey().method_40225(XP_HARVESTER_KEY) || entry.getKey().method_40226(XP_HARVESTER_ID)) {
                return entry.getIntValue();
            }
        }
        return 0;
    }

    private static boolean isVanillaOre(class_2680 state) {
        return state.method_26164(class_3481.field_28988)
                || state.method_26164(class_3481.field_29195)
                || state.method_26164(class_3481.field_23062)
                || state.method_26164(class_3481.field_28991)
                || state.method_26164(class_3481.field_28990)
                || state.method_26164(class_3481.field_28989);
    }

    private BlockBreakHandler() {}
}
