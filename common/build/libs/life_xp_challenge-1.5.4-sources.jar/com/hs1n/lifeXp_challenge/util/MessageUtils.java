package com.hs1n.lifeXp_challenge.util;

import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/**
 * Утилита для унифицированного форматирования и отправки сообщений мода с префиксом.
 */
public final class MessageUtils {

    private MessageUtils() {}

    public static class_5250 prefix() {
        return class_2561.method_43471("lifexp.message.prefix").method_27692(class_124.field_1065);
    }

    public static class_5250 info(String translationKey, Object... args) {
        return prefix().method_10852(class_2561.method_43469(translationKey, args).method_27692(class_124.field_1075));
    }

    public static class_5250 error(String translationKey, Object... args) {
        return prefix().method_10852(class_2561.method_43469(translationKey, args).method_27692(class_124.field_1061));
    }

    public static void sendInfo(class_1657 player, String translationKey, Object... args) {
        player.method_43496(info(translationKey, args));
    }

    public static void sendError(class_1657 player, String translationKey, Object... args) {
        player.method_43496(error(translationKey, args));
    }

    public static void sendActionBarError(class_1657 player, String translationKey, Object... args) {
        player.method_7353(error(translationKey, args), true);
    }

    public static void sendActionBarInfo(class_1657 player, String translationKey, Object... args) {
        player.method_7353(info(translationKey, args), true);
    }
}
