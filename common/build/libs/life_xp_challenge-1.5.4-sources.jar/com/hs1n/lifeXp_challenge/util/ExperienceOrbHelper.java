package com.hs1n.lifeXp_challenge.util;

import com.hs1n.lifeXp_challenge.mixin.ExperienceOrbAccessor;
import java.util.List;
import net.minecraft.class_1303;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public final class ExperienceOrbHelper {
    public static final double MERGE_RADIUS = 2.0;

    private ExperienceOrbHelper() {}

    /**
     * Spawns a single clumped ExperienceOrb or merges into an existing orb within 2.0 blocks.
     */
    public static void spawnClumpedOrb(class_3218 level, class_243 pos, int totalXp) {
        if (totalXp <= 0) return;

        class_238 aabb = new class_238(
                pos.field_1352 - MERGE_RADIUS, pos.field_1351 - MERGE_RADIUS, pos.field_1350 - MERGE_RADIUS,
                pos.field_1352 + MERGE_RADIUS, pos.field_1351 + MERGE_RADIUS, pos.field_1350 + MERGE_RADIUS
        );

        List<class_1303> nearby = level.method_8390(
                class_1303.class, aabb, orb -> orb.method_5805() && !orb.method_31481()
        );

        if (!nearby.isEmpty()) {
            class_1303 target = nearby.get(0);
            ExperienceOrbAccessor accessor = (ExperienceOrbAccessor) target;
            accessor.lifeXp$setValue(target.method_5919() + totalXp);
            accessor.lifeXp$setCount(1);
            return;
        }

        class_1303 orb = new class_1303(level, pos.field_1352, pos.field_1351, pos.field_1350, totalXp);
        level.method_8649(orb);
    }
}
