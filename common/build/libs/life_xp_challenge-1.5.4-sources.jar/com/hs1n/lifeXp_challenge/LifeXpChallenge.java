package com.hs1n.lifeXp_challenge;

import com.hs1n.lifeXp_challenge.command.LifeXpCommand;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import com.hs1n.lifeXp_challenge.registry.ModCreativeTabs;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.service.AttributeService;
import com.hs1n.lifeXp_challenge.service.LifeBottleService;
import dev.architectury.event.events.common.CommandRegistrationEvent;
import dev.architectury.event.events.common.PlayerEvent;
import net.minecraft.class_3222;
import dev.architectury.event.events.common.EntityEvent;
import com.hs1n.lifeXp_challenge.service.KillStreakService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LifeXpChallenge {
    public static final String MOD_ID = "life_xp_challenge";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static void init() {
        LifeXpConfig.load();
        
        com.hs1n.lifeXp_challenge.registry.ModDataComponents.init();
        ModItems.ITEMS.register();
        com.hs1n.lifeXp_challenge.registry.ModMobEffects.init();
        com.hs1n.lifeXp_challenge.registry.ModPotions.init();
        com.hs1n.lifeXp_challenge.registry.ModLootFunctions.init();
        ModCreativeTabs.CREATIVE_MODE_TABS.register();

        com.hs1n.lifeXp_challenge.event.BlockBreakHandler.init();
        com.hs1n.lifeXp_challenge.event.FishingLootHandler.init();

        com.hs1n.lifeXp_challenge.network.LifeXpNetworking.registerServerReceiver();

        CommandRegistrationEvent.EVENT.register((dispatcher, registryAccess, selection) -> {
            LifeXpCommand.register(dispatcher);
        });

        PlayerEvent.PLAYER_JOIN.register(player -> {
            AttributeService.recalculate(player);
            if (!player.method_5752().contains(LifeXpCommand.PRESET_TAG)) {
                com.hs1n.lifeXp_challenge.network.LifeXpNetworking.sendOpenPresetScreen(player);
            }
        });

        PlayerEvent.PLAYER_RESPAWN.register((net.minecraft.class_3222 player, boolean conqueredEnd, net.minecraft.class_1297.class_5529 removalReason) -> {
            AttributeService.recalculate(player);
            if (!conqueredEnd) {
                KillStreakService.resetStreak(player);
            }
        });

        PlayerEvent.CHANGE_DIMENSION.register((net.minecraft.class_3222 player, net.minecraft.class_5321<net.minecraft.class_1937> oldLevel, net.minecraft.class_5321<net.minecraft.class_1937> newLevel) -> {
            AttributeService.recalculate(player);
        });

        EntityEvent.LIVING_DEATH.register((entity, source) -> {
            if (entity instanceof class_3222 player) {
                com.hs1n.lifeXp_challenge.service.DeathTaxService.onPlayerDeath(player, source);
            }
            if (source.method_5529() instanceof class_3222 player && entity != player) {
                KillStreakService.onMobKilled(player);
            }
            return dev.architectury.event.EventResult.pass();
        });

        dev.architectury.registry.CreativeTabRegistry.append(ModCreativeTabs.LIFE_XP_TAB, ModItems.DYNAMIC_XP_BOTTLE, ModItems.LIFE_BOTTLE, ModItems.SHIELD_CORE);
    }
}
