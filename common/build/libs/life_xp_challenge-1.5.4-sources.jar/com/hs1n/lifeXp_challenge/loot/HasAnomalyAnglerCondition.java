package com.hs1n.lifeXp_challenge.loot;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.registry.ModLootFunctions;
import com.mojang.serialization.MapCodec;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Set;
import net.minecraft.class_169;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_5342;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class HasAnomalyAnglerCondition implements class_5341 {
    public static final class_2960 ANOMALY_ANGLER_ID = class_2960.method_60655(LifeXpChallenge.MOD_ID, "anomaly_angler");
    public static final class_5321<class_1887> ANOMALY_ANGLER_KEY = class_5321.method_29179(class_7924.field_41265, ANOMALY_ANGLER_ID);

    public static final HasAnomalyAnglerCondition INSTANCE = new HasAnomalyAnglerCondition();
    public static final MapCodec<HasAnomalyAnglerCondition> CODEC = MapCodec.unit(INSTANCE);

    @Override
    public class_5342 method_29325() {
        return ModLootFunctions.HAS_ANOMALY_ANGLER.get();
    }

    @Override
    public Set<class_169<?>> method_293() {
        return Set.of(class_181.field_1229);
    }

    @Override
    public boolean test(class_47 context) {
        class_1799 tool = context.method_296(class_181.field_1229);
        if (tool == null || tool.method_7960()) {
            return false;
        }
        class_9304 enchantments = tool.method_57825(class_9334.field_49633, class_9304.field_49385);
        for (var entry : enchantments.method_57539()) {
            if (entry.getKey().method_40225(ANOMALY_ANGLER_KEY) || entry.getKey().method_40226(ANOMALY_ANGLER_ID)) {
                return entry.getIntValue() > 0;
            }
        }
        return false;
    }

    public static class_5341.class_210 builder() {
        return () -> INSTANCE;
    }
}
