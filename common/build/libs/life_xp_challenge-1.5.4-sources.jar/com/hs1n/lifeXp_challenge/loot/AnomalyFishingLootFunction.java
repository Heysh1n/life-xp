package com.hs1n.lifeXp_challenge.loot;

import com.hs1n.lifeXp_challenge.registry.ModDataComponents;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.registry.ModLootFunctions;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_120;
import net.minecraft.class_1799;
import net.minecraft.class_47;
import net.minecraft.class_5339;
import net.minecraft.class_5341;
import net.minecraft.class_5819;
import net.minecraft.class_9334;

public class AnomalyFishingLootFunction extends class_120 {
    public static final MapCodec<AnomalyFishingLootFunction> CODEC = RecordCodecBuilder.mapCodec(
            instance -> method_53344(instance).apply(instance, AnomalyFishingLootFunction::new)
    );

    public AnomalyFishingLootFunction(List<class_5341> predicates) {
        super(predicates);
    }

    @Override
    public class_5339<AnomalyFishingLootFunction> method_29321() {
        return ModLootFunctions.ANOMALY_FISHING_LOOT.get();
    }

    @Override
    protected class_1799 method_522(class_1799 stack, class_47 context) {
        class_5819 random = context.method_294();

        // а) Для life_bottle: оставляем предмету 1-2 единицы прочности до поломки
        if (stack.method_31574(ModItems.LIFE_BOTTLE.get())) {
            int maxDamage = stack.method_7936();
            int remaining = random.method_43056() ? 1 : 2;
            int damage = Math.max(1, maxDamage - remaining);
            stack.method_57379(class_9334.field_49629, damage);
        }

        // б) Для dynamic_xp_bottle: случайный stored_xp от 5 до 40
        if (stack.method_31574(ModItems.DYNAMIC_XP_BOTTLE.get())) {
            int randomXp = random.method_43051(5, 41);
            stack.method_57379(ModDataComponents.STORED_XP.get(), randomXp);
        }

        return stack;
    }

    public static class_120.class_121<?> builder() {
        return method_520(AnomalyFishingLootFunction::new);
    }
}
