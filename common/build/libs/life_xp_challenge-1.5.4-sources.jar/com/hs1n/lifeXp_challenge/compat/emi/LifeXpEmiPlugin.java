package com.hs1n.lifeXp_challenge.compat.emi;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import dev.emi.emi.api.EmiEntrypoint;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiInfoRecipe;
import dev.emi.emi.api.stack.EmiStack;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

@EmiEntrypoint
public class LifeXpEmiPlugin implements EmiPlugin {

    @Override
    public void register(EmiRegistry registry) {
        registry.addRecipe(new EmiInfoRecipe(
                List.of(EmiStack.of(ModItems.LIFE_BOTTLE.get())),
                List.of(class_2561.method_43471("jei.life_xp_challenge.life_bottle.info")),
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "/info/life_bottle")
        ));

        registry.addRecipe(new EmiInfoRecipe(
                List.of(EmiStack.of(ModItems.DYNAMIC_XP_BOTTLE.get())),
                List.of(class_2561.method_43471("jei.life_xp_challenge.dynamic_xp_bottle.info")),
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "/info/dynamic_xp_bottle")
        ));

        registry.addRecipe(new EmiInfoRecipe(
                List.of(EmiStack.of(ModItems.SHIELD_CORE.get())),
                List.of(class_2561.method_43471("jei.life_xp_challenge.shield_core.info")),
                class_2960.method_60655(LifeXpChallenge.MOD_ID, "/info/shield_core")
        ));
    }
}
