package com.hs1n.lifeXp_challenge.item;

import com.hs1n.lifeXp_challenge.util.MessageUtils;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3902;
import net.minecraft.class_437;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Пузырёк жизни с прочностью 3.
 * При гибели сохраняет инвентарь игрока через Data Components (1.21.1).
 * При Shift + ПКМ проверяет наличие свободного места в инвентаре и возвращает сохранённые вещи.
 */
public class LifeBottleItem extends class_1792 {

    public static final String NBT_SAVED_INVENTORY = "SavedInventory";

    public LifeBottleItem(class_1792.class_1793 properties) {
        // Добавляем флаг скрытия дополнительных ванильных тултипов (включая ванильную прочность)
        super(properties.method_57349(class_9334.field_49638, class_3902.field_17274));
    }

    public static boolean hasSavedInventory(class_1799 stack) {
        class_9279 customData = stack.method_57824(class_9334.field_49628);
        return customData != null && customData.method_57450(NBT_SAVED_INVENTORY);
    }

    public static class_2499 getSavedInventory(class_1799 stack) {
        class_9279 customData = stack.method_57824(class_9334.field_49628);
        if (customData == null) return null;
        class_2487 tag = customData.method_57461();
        return tag.method_10554(NBT_SAVED_INVENTORY, class_2520.field_33260);
    }

    public static void setSavedInventory(class_1799 stack, class_2499 listTag) {
        class_2487 tag = new class_2487();
        class_9279 existing = stack.method_57824(class_9334.field_49628);
        if (existing != null) {
            tag = existing.method_57461();
        }
        tag.method_10566(NBT_SAVED_INVENTORY, listTag);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
    }

    public static void clearSavedInventory(class_1799 stack) {
        class_9279 existing = stack.method_57824(class_9334.field_49628);
        if (existing != null) {
            class_2487 tag = existing.method_57461();
            tag.method_10551(NBT_SAVED_INVENTORY);
            if (tag.method_33133()) {
                stack.method_57381(class_9334.field_49628);
            } else {
                stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
            }
        }
    }

    /**
     * Подсчитывает общее количество полностью свободных слотов во ВСЕМ инвентаре игрока.
     */
    public static int getEmptySlotCount(class_1661 inventory) {
        int count = 0;
        for (class_1799 item : inventory.field_7547) {
            if (item.method_7960()) count++;
        }
        for (class_1799 armor : inventory.field_7548) {
            if (armor.method_7960()) count++;
        }
        for (class_1799 offhand : inventory.field_7544) {
            if (offhand.method_7960()) count++;
        }
        return count;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        if (hasSavedInventory(stack)) {
            if (player.method_5715()) {
                class_2499 listTag = getSavedInventory(stack);
                int savedCount = (listTag != null) ? listTag.size() : 0;

                // 1. Точно считаем пустые слоты во всем инвентаре
                int freeSlots = getEmptySlotCount(player.method_31548());

                // 2. Если пустых слотов меньше, чем предметов внутри бутылька
                if (freeSlots < savedCount) {
                    if (level.method_8608()) {
                        // Жестко отменяем и выводим красное сообщение
                        MessageUtils.sendActionBarError(player, "lifexp.message.not_enough_space");
                    }
                    return class_1271.method_22431(stack);
                }

                // 3. Только если места 100% хватает, выполняем распаковку
                if (!level.method_8608()) {
                    unpackInventory(level, player, stack, listTag);
                }
                
                return class_1271.method_29237(stack, level.method_8608());
            }
        }
        return class_1271.method_22430(stack);
    }

    private void unpackInventory(class_1937 level, class_1657 player, class_1799 stack, class_2499 listTag) {
        if (listTag == null || listTag.isEmpty()) return;

        // Очищаем NBT с инвентарем перед выдачей вещей
        clearSavedInventory(stack);

        class_1661 inventory = player.method_31548();
        int restoredCount = 0;

        for (int i = 0; i < listTag.size(); i++) {
            class_2487 itemTag = listTag.method_10602(i);
            int slot = itemTag.method_10550("Slot");
            class_1799 item = class_1799.method_57359(player.method_56673(), itemTag);
            
            if (!item.method_7960()) {
                restoredCount++;
                boolean placed = false;
                
                // Шаг 1: Пытаемся вернуть предмет в его родной слот
                if (slot >= 0 && slot < inventory.field_7547.size() && inventory.field_7547.get(slot).method_7960()) {
                    inventory.field_7547.set(slot, item);
                    placed = true;
                } else if (slot >= 100 && slot < 100 + inventory.field_7548.size() && inventory.field_7548.get(slot - 100).method_7960()) {
                    inventory.field_7548.set(slot - 100, item);
                    placed = true;
                } else if (slot >= 150 && slot < 150 + inventory.field_7544.size() && inventory.field_7544.get(slot - 150).method_7960()) {
                    inventory.field_7544.set(slot - 150, item);
                    placed = true;
                }

                // Шаг 2: Если родной слот занят, пробуем обычный add (занимает слоты основного инвентаря)
                if (!placed) {
                    if (inventory.method_7394(item)) {
                        placed = true;
                    }
                }

                // Шаг 3: Если основной инвентарь переполнен, но есть пустые слоты брони/оффхенда
                // (ведь мы считали их как свободные при проверке freeSlots >= savedCount)
                if (!placed) {
                    for (int j = 0; j < inventory.field_7548.size(); j++) {
                        if (inventory.field_7548.get(j).method_7960()) {
                            inventory.field_7548.set(j, item);
                            placed = true;
                            break;
                        }
                    }
                }
                if (!placed) {
                    for (int j = 0; j < inventory.field_7544.size(); j++) {
                        if (inventory.field_7544.get(j).method_7960()) {
                            inventory.field_7544.set(j, item);
                            placed = true;
                            break;
                        }
                    }
                }

                // Шаг 4: Экстренный сброс на землю (теоретически никогда не сработает из-за жесткой проверки)
                if (!placed) {
                    player.method_7328(item, false);
                }
            }
        }

        // Звуковые эффекты
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_34375, class_3419.field_15248, 1.0f, 1.0f);
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14709, class_3419.field_15248, 0.5f, 1.5f);

        MessageUtils.sendInfo(player, "lifexp.message.bottle_restored", restoredCount);

        // Если бутылек исчерпал прочность (>= 3 урона), ломаем его
        if (stack.method_7919() >= stack.method_7936()) {
            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                    class_3417.field_15075, class_3419.field_15248, 1.0f, 1.0f);
            stack.method_7934(1);
        }
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return hasSavedInventory(stack) || super.method_7886(stack);
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        int usesLeft = Math.max(0, stack.method_7936() - stack.method_7919());

        if (hasSavedInventory(stack)) {
            class_2499 listTag = getSavedInventory(stack);
            int itemCount = listTag != null ? listTag.size() : 0;
            tooltip.add(class_2561.method_43469("lifexp.life_bottle.contains_items", itemCount)
                    .method_27695(class_124.field_1065, class_124.field_1067));
        }

        if (class_437.method_25442()) {
            tooltip.add(class_2561.method_43471("item.life_xp_challenge.life_bottle.desc")
                    .method_27692(class_124.field_1054));
        } else {
            tooltip.add(class_2561.method_43471("lifexp.tooltip.hold_shift")
                    .method_27692(class_124.field_1063));
        }

        // Цветокоррекция (светофор) для одной кастомной строки прочности
        class_124 durabilityColor;
        if (usesLeft >= 3) {
            durabilityColor = class_124.field_1060;
        } else if (usesLeft == 2) {
            durabilityColor = class_124.field_1065;
        } else {
            durabilityColor = class_124.field_1061;
        }

        tooltip.add(class_2561.method_43469("lifexp.life_bottle.durability", usesLeft, stack.method_7936())
                .method_27692(durabilityColor));
    }
}
