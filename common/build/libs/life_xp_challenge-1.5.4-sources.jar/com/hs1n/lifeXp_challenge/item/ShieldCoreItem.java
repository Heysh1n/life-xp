package com.hs1n.lifeXp_challenge.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_437;

/**
 * Предмет "Ядро Щита" (Shield Core).
 * Служит катализатором в зельеварке для создания Зелья XP-Щита.
 */
public class ShieldCoreItem extends class_1792 {

    public ShieldCoreItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        if (class_437.method_25442()) {
            tooltip.add(class_2561.method_43471("item.life_xp_challenge.shield_core.desc")
                    .method_27692(class_124.field_1080));
        } else {
            tooltip.add(class_2561.method_43471("lifexp.tooltip.hold_shift")
                    .method_27692(class_124.field_1063));
        }
    }
}
