package com.hs1n.lifeXp_challenge.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * Эффект XP-Щита.
 * Наличие этого эффекта на игроке активирует поглощение урона за счет опыта:
 * - Уровень I: 25% урона
 * - Уровень II: 50% урона
 * - Уровень III+: 75% урона
 */
public class XpShieldMobEffect extends class_1291 {

    public XpShieldMobEffect() {
        super(class_4081.field_18271, 0x55E2E9);
    }
}
