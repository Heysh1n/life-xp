package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.util.ExperienceUtils;
import com.hs1n.lifeXp_challenge.util.MessageUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1754;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Миксин в BottleItem для запуска процесса забора опыта в стеклянную бутылочку при Shift + ПКМ.
 */
@Mixin(class_1754.class)
public abstract class MixinBottleItem {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void lifeXp$onUse(class_1937 level, class_1657 player, class_1268 hand,
                              CallbackInfoReturnable<class_1271<class_1799>> cir) {
        if (player.method_5715()) {
            if (ExperienceUtils.getPlayerTotalXp(player) > 0) {
                player.method_6019(hand);
                cir.setReturnValue(class_1271.method_22428(player.method_5998(hand)));
            } else {
                if (level.method_8608()) {
                    MessageUtils.sendActionBarError(player, "lifexp.message.not_enough_xp");
                }
                cir.setReturnValue(class_1271.method_22431(player.method_5998(hand)));
            }
        }
    }
}
