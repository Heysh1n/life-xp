package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.service.AdvancementService;
import com.hs1n.lifeXp_challenge.util.ExperienceSourceHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3222;

@Mixin(class_1303.class)
public abstract class ExperienceOrbMixin {

    @Shadow private int value;
    @Shadow private int count;
    @Shadow public abstract int getValue();

    @Inject(method = "<init>(Lnet/minecraft/world/level/Level;DDDI)V", at = @At("RETURN"))
    private void lifeXp$onOrbConstructed(class_1937 level, double x, double y, double z, int value, CallbackInfo ci) {
        class_1303 orb = (class_1303) (Object) this;
        if (ExperienceSourceHelper.IS_ORE_XP.get()) {
            orb.method_5780("life_xp_ore");
        }
        if (ExperienceSourceHelper.IS_FISHING_XP.get()) {
            orb.method_5780("life_xp_fishing");
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void lifeXp$clumpNearbyOrbs(CallbackInfo ci) {
        class_1303 self = (class_1303) (Object) this;
        if (self.method_37908().field_9236 || !self.method_5805() || self.method_31481()) return;
        if (self.field_6012 % 5 != 0) return;

        class_238 aabb = self.method_5829().method_1014(2.0);
        List<class_1303> nearby = self.method_37908().method_8390(
                class_1303.class, aabb,
                other -> other != self && other.method_5805() && !other.method_31481()
        );

        for (class_1303 other : nearby) {
            ExperienceOrbAccessor otherAccessor = (ExperienceOrbAccessor) other;
            this.value += other.method_5919() * Math.max(1, otherAccessor.lifeXp$getCount());
            this.count = 1;
            if (other.method_5752().contains("life_xp_ore")) {
                self.method_5780("life_xp_ore");
            }
            if (other.method_5752().contains("life_xp_fishing")) {
                self.method_5780("life_xp_fishing");
            }
            other.method_31472();
        }
    }

    @Inject(method = "playerTouch", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;take(Lnet/minecraft/world/entity/Entity;I)V"))
    private void lifeXp$onPlayerTouchOrb(class_1657 player, CallbackInfo ci) {
        if (player instanceof class_3222 serverPlayer) {
            class_1303 orb = (class_1303) (Object) this;
            if (orb.method_5752().contains("life_xp_ore")) {
                AdvancementService.addOreXp(serverPlayer, this.getValue());
            } else if (orb.method_5752().contains("life_xp_fishing")) {
                AdvancementService.addFishingXp(serverPlayer, this.getValue());
            }
        }
    }
}
