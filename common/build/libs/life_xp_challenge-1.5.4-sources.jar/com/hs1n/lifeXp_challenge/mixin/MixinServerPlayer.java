package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import com.hs1n.lifeXp_challenge.util.MessageUtils;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Миксин в ServerPlayer для отправки координат гибели игроку в чат с золотым префиксом и красным текстом.
 */
@Mixin(class_3222.class)
public abstract class MixinServerPlayer {

    @Inject(method = "die", at = @At("HEAD"))
    private void lifeXp$onDeath(class_1282 damageSource, CallbackInfo ci) {
        if (LifeXpConfig.INSTANCE.isShowDeathCoordinates()) {
            class_3222 player = (class_3222) (Object) this;
            MessageUtils.sendError(player, "lifexp.message.death_coords",
                    player.method_31477(),
                    player.method_31478(),
                    player.method_31479()
            );
        }
    }
}
