package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.service.KillStreakService;
import com.hs1n.lifeXp_challenge.util.ExperienceOrbHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1928;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Shadow public abstract boolean wasExperienceConsumed();
    @Shadow public abstract boolean shouldDropExperience();
    @Shadow public abstract int getExperienceReward(class_3218 level, class_1297 killer);
    @Shadow protected abstract boolean isAlwaysExperienceDropper();
    @Shadow protected int lastHurtByPlayerTime;

    @Inject(method = "dropExperience", at = @At("HEAD"), cancellable = true)
    private void lifeXp$clumpMobDropExperience(class_1297 entity, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908() instanceof class_3218 serverLevel
                && !this.wasExperienceConsumed()
                && (this.isAlwaysExperienceDropper() || (this.lastHurtByPlayerTime > 0 && this.shouldDropExperience() && serverLevel.method_8450().method_8355(class_1928.field_19391)))) {
            int reward = this.getExperienceReward(serverLevel, entity);
            if (entity instanceof class_3222 player) {
                reward = KillStreakService.modifyExperience(player, reward);
            }
            if (reward > 0) {
                ExperienceOrbHelper.spawnClumpedOrb(serverLevel, self.method_19538(), reward);
            }
            ci.cancel();
        }
    }
}
