package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.util.ExperienceSourceHelper;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_6017;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2248.class)
public abstract class BlockExperienceMixin {

    @Unique
    private static final class_6862<class_2248> COMMON_ORES = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "ores"));

    @Unique
    private static boolean lifeXp$isOre(class_2680 state) {
        return state.method_26164(class_3481.field_29193)
                || state.method_26164(class_3481.field_28989)
                || state.method_26164(class_3481.field_29194)
                || state.method_26164(class_3481.field_28991)
                || state.method_26164(class_3481.field_28990)
                || state.method_26164(class_3481.field_23062)
                || state.method_26164(class_3481.field_28988)
                || state.method_26164(class_3481.field_29195)
                || state.method_26164(COMMON_ORES);
    }

    @Inject(method = "tryDropExperience", at = @At("HEAD"))
    private void lifeXp$beforeDropExperience(class_3218 level, class_2338 pos, class_1799 itemStack, class_6017 intProvider, CallbackInfo ci) {
        class_2248 self = (class_2248) (Object) this;
        if (lifeXp$isOre(self.method_9564())) {
            ExperienceSourceHelper.IS_ORE_XP.set(true);
        }
    }

    @Inject(method = "tryDropExperience", at = @At("RETURN"))
    private void lifeXp$afterDropExperience(class_3218 level, class_2338 pos, class_1799 itemStack, class_6017 intProvider, CallbackInfo ci) {
        ExperienceSourceHelper.IS_ORE_XP.set(false);
    }
}
