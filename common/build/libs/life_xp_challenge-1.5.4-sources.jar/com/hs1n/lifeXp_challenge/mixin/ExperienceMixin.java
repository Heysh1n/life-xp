package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.service.AttributeService;
import com.hs1n.lifeXp_challenge.service.KillStreakService;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехватывает изменения опыта игрока и запускает пересчёт атрибутов.
 * Оптимизировано: пересчёт срабатывает ТОЛЬКО при реальном изменении experienceLevel.
 * Изменение experienceProgress (подбор сфер без апа уровня) полностью игнорируется.
 */
@Mixin(class_1657.class)
public abstract class ExperienceMixin {

    @Unique
    private int lifeXp$preLevel;

    @Inject(method = "giveExperienceLevels", at = @At("TAIL"))
    private void lifeXp$onGiveExperienceLevels(int levels, CallbackInfo ci) {
        AttributeService.recalculate((class_1657) (Object) this);
    }

    @Inject(method = "giveExperiencePoints", at = @At("HEAD"))
    private void lifeXp$onGiveExperiencePointsHead(int amount, CallbackInfo ci) {
        this.lifeXp$preLevel = ((class_1657) (Object) this).field_7520;
    }

    @Inject(method = "giveExperiencePoints", at = @At("TAIL"))
    private void lifeXp$onGiveExperiencePointsTail(int amount, CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        // Пересчёт статов срабатывает ТОЛЬКО при изменении experienceLevel!
        if (player.field_7520 != this.lifeXp$preLevel) {
            AttributeService.recalculate(player);
        }
    }
}
