package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.service.XpShieldService;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1657.class)
public abstract class PlayerDamageMixin {

    @ModifyVariable(method = "actuallyHurt", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float lifeXp$absorbDamageWithXp(float amount, class_1282 source) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof class_3222 serverPlayer) {
            return XpShieldService.absorbDamage(serverPlayer, source, amount);
        }
        return amount;
    }

    @org.spongepowered.asm.mixin.injection.Inject(method = "actuallyHurt", at = @At("TAIL"))
    private void lifeXp$checkLifeOrDeath(class_1282 damageSource, float amount, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        if (player instanceof class_3222 serverPlayer) {
            com.hs1n.lifeXp_challenge.service.AdvancementService.checkLifeOrDeath(serverPlayer);
        }
    }
}
