package com.hs1n.lifeXp_challenge.mixin;

import net.minecraft.class_1303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1303.class)
public interface ExperienceOrbAccessor {
    @Accessor("value")
    int lifeXp$getValue();

    @Accessor("value")
    void lifeXp$setValue(int value);

    @Accessor("count")
    int lifeXp$getCount();

    @Accessor("count")
    void lifeXp$setCount(int count);
}
