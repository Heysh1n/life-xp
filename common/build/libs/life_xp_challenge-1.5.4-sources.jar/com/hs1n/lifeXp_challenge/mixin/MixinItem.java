package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.item.DynamicXpBottleItem;
import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.util.ExperienceUtils;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5328;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Миксин в Item для поддержки зажатия стеклянной бутылочки (onUseTick) и переливания опыта в DYNAMIC_XP_BOTTLE.
 */
@Mixin(class_1792.class)
public abstract class MixinItem {

    @Inject(method = "getUseAnimation", at = @At("HEAD"), cancellable = true)
    private void lifeXp$getUseAnimation(class_1799 stack, CallbackInfoReturnable<class_1839> cir) {
        if (stack.method_31574(class_1802.field_8469)) {
            cir.setReturnValue(class_1839.field_8953);
        }
    }

    @Inject(method = "getUseDuration", at = @At("HEAD"), cancellable = true)
    private void lifeXp$getUseDuration(class_1799 stack, class_1309 entity, CallbackInfoReturnable<Integer> cir) {
        if (stack.method_31574(class_1802.field_8469)) {
            cir.setReturnValue(72000);
        }
    }

    @Inject(method = "onUseTick", at = @At("HEAD"))
    private void lifeXp$onUseTick(class_1937 level, class_1309 livingEntity, class_1799 stack, int remainingUseTicks, CallbackInfo ci) {
        if (stack.method_31574(class_1802.field_8469) && livingEntity instanceof class_1657 player) {
            class_1792 item = (class_1792) (Object) this;
            int ticksUsed = item.method_7881(stack, player) - remainingUseTicks;

            if (ticksUsed > 0 && ticksUsed % 10 == 0) {
                if (!level.method_8608()) {
                    if (ExperienceUtils.getPlayerTotalXp(player) > 0) {
                        int targetLevel = Math.max(0, player.field_7520 - 1);
                        int needed = ExperienceUtils.getXpNeededToLevelUp(targetLevel);
                        int deducted = ExperienceUtils.deductPlayerXp(player, needed);

                        if (deducted > 0) {
                            int stored = (int) Math.round(deducted * 0.9); // 10% налог
                            if (stored <= 0) stored = 1;

                            class_1799 dynamicBottle = new class_1799(ModItems.DYNAMIC_XP_BOTTLE.get());
                            DynamicXpBottleItem.setStoredXp(dynamicBottle, stored);

                            player.method_6021();
                            class_1799 result = class_5328.method_30012(stack, player, dynamicBottle);
                            player.method_6122(player.method_6058(), result);

                            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                                    class_3417.field_14779, class_3419.field_15248, 0.8f, 1.0f);
                            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                                    class_3417.field_14627, class_3419.field_15248, 0.4f, 1.2f);
                        }
                    } else {
                        player.method_6021();
                    }
                }
            }
        }
    }
}
