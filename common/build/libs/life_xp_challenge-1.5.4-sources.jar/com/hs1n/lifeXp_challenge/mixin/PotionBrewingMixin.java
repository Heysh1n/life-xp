package com.hs1n.lifeXp_challenge.mixin;

import com.hs1n.lifeXp_challenge.registry.ModItems;
import com.hs1n.lifeXp_challenge.registry.ModPotions;
import net.minecraft.class_1802;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1845.class)
public abstract class PotionBrewingMixin {

    @Inject(method = "addVanillaMixes", at = @At("TAIL"))
    private static void lifeXp$addCustomPotionMixes(class_1845.class_9665 builder, CallbackInfo ci) {
        // Awkward Potion + shield_core = Зелье XP-Щита (3:00)
        builder.method_59705(class_1847.field_8999, ModItems.SHIELD_CORE.get(), ModPotions.XP_SHIELD);
        // XP-Щит + Redstone = Долгое зелье XP-Щита (8:00)
        builder.method_59705(ModPotions.XP_SHIELD, class_1802.field_8725, ModPotions.LONG_XP_SHIELD);
        // XP-Щит + Glowstone = Сильное зелье XP-Щита II (1:30)
        builder.method_59705(ModPotions.XP_SHIELD, class_1802.field_8601, ModPotions.STRONG_XP_SHIELD);
        // Сильное зелье XP-Щита II + Звезда Незера = Ультра зелье XP-Щита III (1:00)
        builder.method_59705(ModPotions.STRONG_XP_SHIELD, class_1802.field_8137, ModPotions.ULTRA_XP_SHIELD);
    }
}
