package com.hs1n.lifeXp_challenge.command;

import com.hs1n.lifeXp_challenge.config.AttributeConfigNode;
import com.hs1n.lifeXp_challenge.config.DifficultyDirection;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import com.hs1n.lifeXp_challenge.config.LifeXpPresets;
import com.hs1n.lifeXp_challenge.service.AttributeService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.util.Map;

public final class LifeXpCommand {

    private static final String[] ATTR_KEYS = {
            "max_health", "movement_speed", "attack_damage", "attack_speed",
            "armor_toughness", "knockback_resistance", "block_interaction_range",
            "entity_interaction_range", "block_break_speed", "sneaking_speed",
            "submerged_mining_speed", "sweeping_damage_ratio", "safe_fall_distance",
            "oxygen_bonus", "burning_time"
    };

    private LifeXpCommand() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("lifexp")
                .requires(source -> source.method_9259(2))

                .then(class_2170.method_9247("reload")
                        .executes(LifeXpCommand::executeReload))

                .then(class_2170.method_9247("status")
                        .executes(LifeXpCommand::executeStatus))

                .then(class_2170.method_9247("get")
                        .then(class_2170.method_9247("maxLevel")
                                .executes(ctx -> executeGetSimple(ctx, "maxLevel",
                                        String.valueOf(LifeXpConfig.INSTANCE.getMaxLevel()))))
                        .then(class_2170.method_9247("deathXpTax")
                                .executes(ctx -> executeGetSimple(ctx, "deathXpTax",
                                        String.format("%.4f", LifeXpConfig.INSTANCE.getDeathXpTax()))))
                        .then(class_2170.method_9247("deathCoords")
                                .executes(ctx -> executeGetSimple(ctx, "deathCoords",
                                        String.valueOf(LifeXpConfig.INSTANCE.isShowDeathCoordinates()))))
                        .then(class_2170.method_9247("attr")
                                .then(class_2170.method_9244("attribute", StringArgumentType.word())
                                        .suggests((ctx, builder) -> class_2172.method_9253(ATTR_KEYS, builder))
                                        .executes(LifeXpCommand::executeGetAttr))))

                .then(class_2170.method_9247("set")
                        .then(class_2170.method_9247("maxLevel")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer(1))
                                        .executes(LifeXpCommand::executeSetMaxLevel)))
                        .then(class_2170.method_9247("deathXpTax")
                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(0.0, 1.0))
                                        .executes(LifeXpCommand::executeSetDeathXpTax)))
                        .then(class_2170.method_9247("deathCoords")
                                .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                        .executes(LifeXpCommand::executeSetDeathCoords)))
                        .then(class_2170.method_9247("attr")
                                .then(class_2170.method_9244("attribute", StringArgumentType.word())
                                        .suggests((ctx, builder) -> class_2172.method_9253(ATTR_KEYS, builder))
                                        .then(class_2170.method_9247("start")
                                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg())
                                                        .executes(ctx -> executeSetAttr(ctx, "start"))))
                                        .then(class_2170.method_9247("mid")
                                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg())
                                                        .executes(ctx -> executeSetAttr(ctx, "mid"))))
                                        .then(class_2170.method_9247("end")
                                                .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg())
                                                        .executes(ctx -> executeSetAttr(ctx, "end")))))))

                .then(class_2170.method_9247("preset")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                                .suggests((ctx, builder) -> class_2172.method_9253(LifeXpPresets.PRESET_NAMES, builder))
                                .executes(LifeXpCommand::executePreset)))
                                
                .then(class_2170.method_9247("export")
                        .executes(LifeXpCommand::executeExport))
                        
                .then(class_2170.method_9247("top")
                        .executes(LifeXpCommand::executeTop))
        );
    }

    private static int executeReload(CommandContext<class_2168> ctx) {
        LifeXpConfig.load();
        int count = recalculateAllPlayers(ctx.getSource().method_9211());
        ctx.getSource().method_9226(
                () -> prefix().method_10852(class_2561.method_43469("lifexp.command.reload.success", count)
                        .method_27692(class_124.field_1060)),
                true);
        return count;
    }

    private static int executeStatus(CommandContext<class_2168> ctx) {
        LifeXpConfig cfg = LifeXpConfig.INSTANCE;
        class_2168 source = ctx.getSource();

        source.method_9226(() -> class_2561.method_43471("lifexp.command.status.header")
                .method_27695(class_124.field_1065, class_124.field_1067), false);

        source.method_9226(() -> class_2561.method_43469("lifexp.command.status.general",
                        cfg.getMaxLevel(),
                        cfg.getDeathXpTax(),
                        cfg.isShowDeathCoordinates() ? "ON" : "OFF")
                .method_27692(class_124.field_1054), false);

        source.method_9226(() -> class_2561.method_43471("lifexp.command.status.visuals")
                .method_27692(class_124.field_1075), false);

        source.method_9226(() -> class_2561.method_43471("lifexp.command.status.attr_header")
                .method_27692(class_124.field_1080), false);

        for (Map.Entry<String, AttributeConfigNode> entry : cfg.getNodes().entrySet()) {
            String key = entry.getKey();
            AttributeConfigNode node = entry.getValue();
            String dir = node.getDirection() == DifficultyDirection.INVERSE ? "↑=Harder" : "↑=Easier";
            source.method_9226(() -> class_2561.method_43469("lifexp.command.status.attr",
                            key,
                            node.getStartValue(),
                            node.getMidValue(),
                            node.getEndValue(),
                            dir)
                    .method_27692(class_124.field_1080), false);
        }

        return 1;
    }

    private static int executeGetSimple(CommandContext<class_2168> ctx, String param, String value) {
        ctx.getSource().method_9226(
                () -> prefix().method_10852(class_2561.method_43469("lifexp.command.get.value", param, value)
                        .method_27692(class_124.field_1054)),
                false);
        return 1;
    }

    private static int executeGetAttr(CommandContext<class_2168> ctx) {
        String attrName = StringArgumentType.getString(ctx, "attribute");
        AttributeConfigNode node = LifeXpConfig.INSTANCE.getNode(attrName);
        if (node == null) {
            ctx.getSource().method_9213(
                    prefix().method_10852(class_2561.method_43469("lifexp.command.error.unknown_attr", attrName)
                            .method_27692(class_124.field_1061)));
            return 0;
        }

        String dir = node.getDirection() == DifficultyDirection.INVERSE ? "↑=Harder" : "↑=Easier";
        ctx.getSource().method_9226(
                () -> prefix().method_10852(class_2561.method_43469("lifexp.command.status.attr",
                                attrName,
                                node.getStartValue(),
                                node.getMidValue(),
                                node.getEndValue(),
                                dir)
                        .method_27692(class_124.field_1054)),
                false);
        return 1;
    }

    private static int executeSetMaxLevel(CommandContext<class_2168> ctx) {
        int value = IntegerArgumentType.getInteger(ctx, "value");
        LifeXpConfig.INSTANCE.setMaxLevel(value);
        return saveAndNotify(ctx, "maxLevel", String.valueOf(value));
    }

    private static int executeSetDeathXpTax(CommandContext<class_2168> ctx) {
        double value = DoubleArgumentType.getDouble(ctx, "value");
        LifeXpConfig.INSTANCE.setDeathXpTax(value);
        return saveAndNotify(ctx, "deathXpTax", String.format("%.4f", value));
    }

    private static int executeSetDeathCoords(CommandContext<class_2168> ctx) {
        boolean value = BoolArgumentType.getBool(ctx, "value");
        LifeXpConfig.INSTANCE.setShowDeathCoordinates(value);
        return saveAndNotify(ctx, "deathCoords", String.valueOf(value));
    }


    private static int executeSetAttr(CommandContext<class_2168> ctx, String field) {
        String attrName = StringArgumentType.getString(ctx, "attribute");
        double value = DoubleArgumentType.getDouble(ctx, "value");

        AttributeConfigNode node = LifeXpConfig.INSTANCE.getNode(attrName);
        if (node == null) {
            ctx.getSource().method_9213(
                    prefix().method_10852(class_2561.method_43469("lifexp.command.error.unknown_attr", attrName)
                            .method_27692(class_124.field_1061)));
            return 0;
        }

        switch (field) {
            case "start" -> node.setStartValue(value);
            case "mid"   -> node.setMidValue(value);
            case "end"   -> node.setEndValue(value);
        }

        return saveAndNotify(ctx, attrName + "." + field, String.format("%.4f", value));
    }

    public static final String PRESET_TAG = "lifexp_preset_chosen";

    private static int executePreset(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        class_3222 player = source.method_44023();

        // Проверяем перманентную блокировку выбора пресета (Origins-style)
        if (LifeXpConfig.INSTANCE.isLockPresetAfterSelection() && player != null && player.method_5752().contains(PRESET_TAG)) {
            source.method_9213(prefix().method_10852(class_2561.method_43471("lifexp.error.preset_locked")
                    .method_27692(class_124.field_1061)));
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "name");

        if (!LifeXpPresets.apply(name)) {
            source.method_9213(
                    prefix().method_10852(class_2561.method_43469("lifexp.command.error.unknown_preset", name)
                            .method_27692(class_124.field_1061)));
            return 0;
        }

        // Перманентно выставляем тег игроку
        if (player != null) {
            player.method_5780(PRESET_TAG);
        }

        LifeXpConfig.save();
        int count = recalculateAllPlayers(source.method_9211());
        source.method_9226(
                () -> prefix().method_10852(class_2561.method_43469("lifexp.command.preset.applied", name, count)
                        .method_27692(class_124.field_1060)),
                true);
        return count;
    }

    private static int executeExport(CommandContext<class_2168> ctx) {
        String json = LifeXpConfig.exportToJsonString();
        ctx.getSource().method_9226(() -> prefix().method_10852(class_2561.method_43471("lifexp.command.export.success")
                .method_27694(style -> style
                        .method_10977(class_124.field_1060)
                        .method_30938(true)
                        .method_10958(new net.minecraft.class_2558(net.minecraft.class_2558.class_2559.field_21462, json))
                        .method_10949(new net.minecraft.class_2568(net.minecraft.class_2568.class_5247.field_24342, class_2561.method_43471("lifexp.command.export.hover"))))), false);
        return 1;
    }

    private static int executeTop(CommandContext<class_2168> ctx) {
        java.util.List<class_3222> players = new java.util.ArrayList<>(ctx.getSource().method_9211().method_3760().method_14571());
        players.sort((p1, p2) -> Integer.compare(p2.field_7520, p1.field_7520));

        ctx.getSource().method_9226(() -> class_2561.method_43471("lifexp.command.top.header").method_27695(class_124.field_1065, class_124.field_1067), false);
        int rank = 1;
        for (class_3222 player : players) {
            final int currentRank = rank;
            ctx.getSource().method_9226(() -> class_2561.method_43469("lifexp.command.top.entry", currentRank, player.method_5820(), player.field_7520)
                    .method_27692(currentRank <= 3 ? class_124.field_1054 : class_124.field_1068), false);
            rank++;
            if (rank > 10) break;
        }
        return 1;
    }

    private static class_5250 prefix() {
        return class_2561.method_43471("lifexp.message.prefix_short").method_27692(class_124.field_1065);
    }

    private static int saveAndNotify(CommandContext<class_2168> ctx, String param, String value) {
        LifeXpConfig.save();
        int count = recalculateAllPlayers(ctx.getSource().method_9211());
        ctx.getSource().method_9226(
                () -> prefix().method_10852(class_2561.method_43469("lifexp.command.set.success", param, value)
                        .method_27692(class_124.field_1060)),
                true);
        return count > 0 ? count : 1;
    }

    private static int recalculateAllPlayers(MinecraftServer server) {
        int count = 0;
        for (class_3222 player : server.method_3760().method_14571()) {
            AttributeService.recalculate(player);
            count++;
        }
        return count;
    }
}
