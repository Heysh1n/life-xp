package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import dev.architectury.registry.registries.DeferredRegister;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_2561;
import net.minecraft.class_7924;

public final class ModCreativeTabs {
    public static final DeferredRegister<class_1761> CREATIVE_MODE_TABS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_44688);

    public static final dev.architectury.registry.registries.RegistrySupplier<class_1761> LIFE_XP_TAB = CREATIVE_MODE_TABS.register("life_xp_tab", () ->
            dev.architectury.registry.CreativeTabRegistry.create(class_2561.method_43471("itemGroup.life_xp_challenge.life_xp_tab"), () -> new net.minecraft.class_1799(ModItems.LIFE_BOTTLE.get())));
}
