package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_5699;
import net.minecraft.class_7924;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

public final class ModDataComponents {
    public static final DeferredRegister<class_9331<?>> DATA_COMPONENTS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_49659);

    public static final RegistrySupplier<class_9331<Integer>> STORED_XP =
            DATA_COMPONENTS.register("stored_xp", () -> class_9331.<Integer>method_57873()
                    .method_57881(class_5699.field_33441)
                    .method_57882(class_9135.field_48550)
                    .method_57880());

    public static void init() {
        DATA_COMPONENTS.register();
    }

    private ModDataComponents() {}
}
