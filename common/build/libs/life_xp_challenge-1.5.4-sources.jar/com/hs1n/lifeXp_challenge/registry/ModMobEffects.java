package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.effect.XpShieldMobEffect;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1291;
import net.minecraft.class_7924;

public final class ModMobEffects {
    public static final DeferredRegister<class_1291> MOB_EFFECTS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_41208);

    public static final RegistrySupplier<class_1291> XP_SHIELD =
            MOB_EFFECTS.register("xp_shield", XpShieldMobEffect::new);

    public static void init() {
        MOB_EFFECTS.register();
    }

    private ModMobEffects() {}
}
