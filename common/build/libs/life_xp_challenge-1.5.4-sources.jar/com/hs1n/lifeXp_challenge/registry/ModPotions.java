package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1293;
import net.minecraft.class_1842;
import net.minecraft.class_7924;

public final class ModPotions {
    public static final DeferredRegister<class_1842> POTIONS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_41215);

    // Зелье XP-Щита (3:00, Уровень I)
    public static final RegistrySupplier<class_1842> XP_SHIELD = POTIONS.register("xp_shield",
            () -> new class_1842("xp_shield", new class_1293(ModMobEffects.XP_SHIELD, 3600, 0)));

    // Долгое зелье XP-Щита (8:00, Уровень I)
    public static final RegistrySupplier<class_1842> LONG_XP_SHIELD = POTIONS.register("long_xp_shield",
            () -> new class_1842("xp_shield", new class_1293(ModMobEffects.XP_SHIELD, 9600, 0)));

    // Сильное зелье XP-Щита (1:30, Уровень II)
    public static final RegistrySupplier<class_1842> STRONG_XP_SHIELD = POTIONS.register("strong_xp_shield",
            () -> new class_1842("xp_shield", new class_1293(ModMobEffects.XP_SHIELD, 1800, 1)));

    // Ультра зелье XP-Щита (1:00, Уровень III / 75% поглощения)
    public static final RegistrySupplier<class_1842> ULTRA_XP_SHIELD = POTIONS.register("ultra_xp_shield",
            () -> new class_1842("ultra_xp_shield", new class_1293(ModMobEffects.XP_SHIELD, 1200, 2)));

    public static void init() {
        POTIONS.register();
    }

    private ModPotions() {}
}
