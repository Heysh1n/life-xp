package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.item.DynamicXpBottleItem;
import com.hs1n.lifeXp_challenge.item.LifeBottleItem;
import com.hs1n.lifeXp_challenge.item.ShieldCoreItem;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1792;
import net.minecraft.class_1814;

public final class ModItems {
    public static final DeferredRegister<class_1792> ITEMS = DeferredRegister.create(LifeXpChallenge.MOD_ID, net.minecraft.class_7924.field_41197);

    public static final RegistrySupplier<class_1792> DYNAMIC_XP_BOTTLE = ITEMS.register("dynamic_xp_bottle",
            () -> new DynamicXpBottleItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8907)));

    public static final RegistrySupplier<class_1792> LIFE_BOTTLE = ITEMS.register("life_bottle",
            () -> new LifeBottleItem(new class_1792.class_1793().method_7895(3).method_24359().method_7889(1).method_7894(class_1814.field_8904)));

    public static final RegistrySupplier<class_1792> SHIELD_CORE = ITEMS.register("shield_core",
            () -> new ShieldCoreItem(new class_1792.class_1793().method_7889(16).method_7894(class_1814.field_8903)));
}
