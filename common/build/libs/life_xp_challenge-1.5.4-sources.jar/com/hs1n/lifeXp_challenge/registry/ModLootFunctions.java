package com.hs1n.lifeXp_challenge.registry;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.loot.AnomalyFishingLootFunction;
import com.hs1n.lifeXp_challenge.loot.HasAnomalyAnglerCondition;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_5339;
import net.minecraft.class_5342;
import net.minecraft.class_7924;

public final class ModLootFunctions {
    public static final DeferredRegister<class_5339<?>> LOOT_FUNCTIONS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_41199);

    public static final DeferredRegister<class_5342> LOOT_CONDITIONS =
            DeferredRegister.create(LifeXpChallenge.MOD_ID, class_7924.field_41198);

    public static final RegistrySupplier<class_5339<AnomalyFishingLootFunction>> ANOMALY_FISHING_LOOT =
            LOOT_FUNCTIONS.register("anomaly_fishing_loot", () -> new class_5339<>(AnomalyFishingLootFunction.CODEC));

    public static final RegistrySupplier<class_5342> HAS_ANOMALY_ANGLER =
            LOOT_CONDITIONS.register("has_anomaly_angler", () -> new class_5342(HasAnomalyAnglerCondition.CODEC));

    public static void init() {
        LOOT_FUNCTIONS.register();
        LOOT_CONDITIONS.register();
    }

    private ModLootFunctions() {}
}
