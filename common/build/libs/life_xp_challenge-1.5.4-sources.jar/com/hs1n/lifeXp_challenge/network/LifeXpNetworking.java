package com.hs1n.lifeXp_challenge.network;

import com.hs1n.lifeXp_challenge.LifeXpChallenge;
import com.hs1n.lifeXp_challenge.command.LifeXpCommand;
import com.hs1n.lifeXp_challenge.config.LifeXpConfig;
import com.hs1n.lifeXp_challenge.config.LifeXpPresets;
import com.hs1n.lifeXp_challenge.service.AttributeService;
import com.hs1n.lifeXp_challenge.service.KillStreakService;
import dev.architectury.networking.NetworkManager;
import io.netty.buffer.Unpooled;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_9129;

public class LifeXpNetworking {
    public static final class_2960 SYNC_STREAK_ID =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "sync_streak");
    public static final class_2960 OPEN_PRESET_SCREEN_ID =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "open_preset_screen");
    public static final class_2960 CHOOSE_PRESET_ID =
            class_2960.method_60655(LifeXpChallenge.MOD_ID, "choose_preset");

    /** Вызывать на клиенте при инициализации */
    public static void registerClientReceiver() {
        NetworkManager.registerReceiver(
                NetworkManager.Side.S2C, SYNC_STREAK_ID, (buf, context) -> {
                    int streak = buf.method_10816();
                    context.queue(() -> KillStreakService.setClientStreak(streak));
                });

        NetworkManager.registerReceiver(
                NetworkManager.Side.S2C, OPEN_PRESET_SCREEN_ID, (buf, context) -> {
                    context.queue(com.hs1n.lifeXp_challenge.client.ClientNetworkingHelper::openPresetScreen);
                });
    }

    /** Вызывать на сервере/общем модуле при инициализации */
    public static void registerServerReceiver() {
        NetworkManager.registerReceiver(
                NetworkManager.Side.C2S, CHOOSE_PRESET_ID, (buf, context) -> {
                    String presetName = buf.method_19772();
                    context.queue(() -> {
                        if (context.getPlayer() instanceof class_3222 player) {
                            if (LifeXpPresets.apply(presetName)) {
                                LifeXpConfig.save();
                                AttributeService.recalculate(player);
                            }
                            player.method_5780(LifeXpCommand.PRESET_TAG);
                        }
                    });
                });
    }

    /** Открыть окно выбора пресета у игрока */
    public static void sendOpenPresetScreen(class_3222 player) {
        class_9129 buf = new class_9129(Unpooled.buffer(), player.field_13995.method_30611());
        NetworkManager.sendToPlayer(player, OPEN_PRESET_SCREEN_ID, buf);
    }

    /** Отправить выбранный пресет на сервер (вызывается с клиента) */
    public static void sendChoosePreset(String presetName) {
        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        if (mc.method_1562() == null) return;
        class_9129 buf = new class_9129(Unpooled.buffer(), mc.method_1562().method_29091());
        buf.method_10814(presetName);
        NetworkManager.sendToServer(CHOOSE_PRESET_ID, buf);
    }

    /** Отправить текущий стрик клиенту */
    public static void syncStreakToClient(class_3222 player) {
        int streak = KillStreakService.getStreak(player);
        class_9129 buf = new class_9129(Unpooled.buffer(), player.field_13995.method_30611());
        buf.method_10804(streak);
        NetworkManager.sendToPlayer(player, SYNC_STREAK_ID, buf);
    }
}
